#ifndef COMMON_H
#define COMMON_H

#define RAM_TEST    (int)0
#define DISK_TEST   (int)1
#define PIC_TEST    (int)2
#define NET_TEST    (int)3
#define UART_TEST   (int)4
#define KBD_TEST    (int)5
#define KDBL_TEST   (int)6
#define MOUS_TEST   (int)7
#define CIRC_TEST   (int)8
#define BLANK_TEST  (int)9

#endif // COMMON_H
