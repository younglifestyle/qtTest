/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout;
    QWidget *test;
    QGridLayout *gridLayout_12;
    QHBoxLayout *horizontalLayout_12;
    QSpacerItem *horizontalSpacer_18;
    QVBoxLayout *verticalLayout;
    QLabel *errorLabel_2;
    QLabel *errorCnt;
    QLabel *timeLabel;
    QLabel *timeCnt;
    QLabel *errorLabel;
    QLabel *circleCnt;
    QSpacerItem *horizontalSpacer_19;
    QSpacerItem *verticalSpacer_15;
    QPushButton *circleButton;
    QPushButton *deleteLogButton;
    QSpacerItem *verticalSpacer_8;
    QLabel *label_7;
    QSpacerItem *verticalSpacer_16;
    QPushButton *checkLogButton;
    QWidget *SideBar;
    QGridLayout *gridLayout_2;
    QWidget *widget;
    QToolButton *toolButton_kbdlite;
    QToolButton *toolButton_mouse;
    QSpacerItem *verticalSpacer;
    QToolButton *toolButton_kbd;
    QToolButton *toolButton_ram;
    QToolButton *toolButton_disk;
    QToolButton *toolButton_pic;
    QToolButton *toolButton_net;
    QToolButton *toolButton_uart;
    QCheckBox *checkBox1;
    QCheckBox *checkBox2;
    QCheckBox *checkBox3;
    QCheckBox *checkBox4;
    QCheckBox *checkBox5;
    QTabWidget *testWidget;
    QWidget *tab_6;
    QGridLayout *gridLayout_6;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_36;
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QPushButton *pushButton3;
    QPushButton *pushButton4;
    QPushButton *pushButton5;
    QPushButton *pushButton6;
    QPushButton *pushButton7;
    QPushButton *pushButton8;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_5;
    QLabel *label_13;
    QSpacerItem *horizontalSpacer_10;
    QSpacerItem *horizontalSpacer;
    QLabel *label_14;
    QHBoxLayout *horizontalLayout_49;
    QPushButton *pushButton_111;
    QPushButton *pushButton_112;
    QPushButton *pushButton_113;
    QPushButton *pushButton_114;
    QPushButton *pushButton_115;
    QPushButton *pushButton_116;
    QPushButton *pushButton_117;
    QPushButton *pushButton_118;
    QSpacerItem *horizontalSpacer_26;
    QHBoxLayout *horizontalLayout_41;
    QPushButton *pushButton9;
    QPushButton *pushButton10;
    QPushButton *pushButton11;
    QPushButton *pushButton12;
    QPushButton *pushButton13;
    QPushButton *pushButton14;
    QPushButton *pushButton15;
    QPushButton *pushButton16;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_39;
    QPushButton *pushButton25;
    QPushButton *pushButton26;
    QPushButton *pushButton27;
    QPushButton *pushButton28;
    QPushButton *pushButton29;
    QPushButton *pushButton30;
    QPushButton *pushButton31;
    QPushButton *pushButton32;
    QSpacerItem *horizontalSpacer_7;
    QHBoxLayout *horizontalLayout_38;
    QPushButton *pushButton17;
    QPushButton *pushButton18;
    QPushButton *pushButton19;
    QPushButton *pushButton20;
    QPushButton *pushButton21;
    QPushButton *pushButton22;
    QPushButton *pushButton23;
    QPushButton *pushButton24;
    QSpacerItem *horizontalSpacer_6;
    QHBoxLayout *horizontalLayout_51;
    QPushButton *pushButton33;
    QPushButton *pushButton34;
    QPushButton *pushButton35;
    QPushButton *pushButton36;
    QPushButton *pushButton37;
    QPushButton *pushButton38;
    QPushButton *pushButton39;
    QPushButton *pushButton40;
    QSpacerItem *horizontalSpacer_35;
    QWidget *tab_9;
    QGridLayout *gridLayout_11;
    QGridLayout *gridLayout_9;
    QFrame *line_5;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_16;
    QHBoxLayout *horizontalLayout_47;
    QPushButton *pushButton_95;
    QPushButton *pushButton_96;
    QPushButton *pushButton_97;
    QPushButton *pushButton_98;
    QPushButton *pushButton_99;
    QPushButton *pushButton_100;
    QPushButton *pushButton_101;
    QPushButton *pushButton_102;
    QSpacerItem *horizontalSpacer_31;
    QHBoxLayout *horizontalLayout_42;
    QPushButton *pushButton_41;
    QPushButton *pushButton_42;
    QPushButton *pushButton_43;
    QPushButton *pushButton_44;
    QPushButton *pushButton_45;
    QPushButton *pushButton_46;
    QPushButton *pushButton_47;
    QPushButton *pushButton_48;
    QSpacerItem *horizontalSpacer_32;
    QHBoxLayout *horizontalLayout_44;
    QPushButton *pushButton_71;
    QPushButton *pushButton_72;
    QPushButton *pushButton_73;
    QPushButton *pushButton_74;
    QPushButton *pushButton_75;
    QPushButton *pushButton_76;
    QPushButton *pushButton_77;
    QPushButton *pushButton_78;
    QSpacerItem *horizontalSpacer_33;
    QLabel *label_17;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_15;
    QHBoxLayout *horizontalLayout_46;
    QPushButton *pushButton41;
    QPushButton *pushButton42;
    QPushButton *pushButton43;
    QPushButton *pushButton44;
    QPushButton *pushButton45;
    QPushButton *pushButton46;
    QPushButton *pushButton47;
    QPushButton *pushButton48;
    QSpacerItem *horizontalSpacer_28;
    QHBoxLayout *horizontalLayout_45;
    QPushButton *pushButton_79;
    QPushButton *pushButton_80;
    QPushButton *pushButton_81;
    QPushButton *pushButton_82;
    QPushButton *pushButton_83;
    QPushButton *pushButton_84;
    QPushButton *pushButton_85;
    QPushButton *pushButton_86;
    QSpacerItem *horizontalSpacer_29;
    QHBoxLayout *horizontalLayout_43;
    QPushButton *pushButton49;
    QPushButton *pushButton50;
    QPushButton *pushButton51;
    QPushButton *pushButton52;
    QPushButton *pushButton53;
    QPushButton *pushButton54;
    QPushButton *pushButton55;
    QPushButton *pushButton56;
    QSpacerItem *horizontalSpacer_30;
    QSpacerItem *verticalSpacer_14;
    QSpacerItem *horizontalSpacer_15;
    QSpacerItem *horizontalSpacer_20;
    QSpacerItem *verticalSpacer_13;
    QWidget *tab_3;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_4;
    QWidget *tab_4;
    QGridLayout *gridLayout_3;
    QVBoxLayout *verticalLayout_4;
    QTextEdit *net_textEdit1;
    QTextEdit *net_textEdit2;
    QTextEdit *net_textEdit2_2;
    QTextEdit *net_textEdit2_3;
    QTextEdit *net_textEdit2_4;
    QTextEdit *net_textEdit2_5;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_12;
    QFrame *frame_2;
    QHBoxLayout *horizontalLayout_21;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *verticalSpacer_3;
    QWidget *tab_5;
    QGridLayout *gridLayout_8;
    QSpacerItem *verticalSpacer_11;
    QLabel *label_28;
    QVBoxLayout *verticalLayout_24;
    QVBoxLayout *verticalLayout_10;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_18;
    QTextEdit *textEdit_1;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_19;
    QTextEdit *textEdit_10;
    QVBoxLayout *verticalLayout_14;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_20;
    QTextEdit *textEdit_2;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_21;
    QTextEdit *textEdit_8;
    QVBoxLayout *verticalLayout_17;
    QVBoxLayout *verticalLayout_15;
    QLabel *label_23;
    QTextEdit *textEdit_3;
    QVBoxLayout *verticalLayout_16;
    QLabel *label_22;
    QTextEdit *textEdit_9;
    QSpacerItem *verticalSpacer_12;
    QLabel *uart_label;
    QWidget *tab_7;
    QGridLayout *gridLayout_10;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_19;
    QFrame *frame;
    QGroupBox *groupBox_3;
    QPushButton *k5PushButton;
    QPushButton *k6PushButton;
    QPushButton *k7PushButton;
    QPushButton *k8PushButton;
    QPushButton *k9PushButton;
    QPushButton *k10PushButton;
    QPushButton *k11PushButton;
    QPushButton *k12PushButton;
    QPushButton *k13PushButton;
    QPushButton *k14PushButton;
    QPushButton *k15PushButton;
    QPushButton *k16PushButton;
    QLineEdit *k9LineEdit;
    QLineEdit *k10LineEdit;
    QLineEdit *k11LineEdit;
    QLineEdit *k12LineEdit;
    QLineEdit *k13LineEdit;
    QLineEdit *k14LineEdit;
    QLineEdit *k15LineEdit;
    QLineEdit *k16LineEdit;
    QPushButton *k1PushButton;
    QPushButton *k4PushButton;
    QPushButton *k2PushButton;
    QPushButton *k3PushButton;
    QLineEdit *k1LineEdit;
    QLineEdit *k2LineEdit;
    QLineEdit *k3LineEdit;
    QLineEdit *k4LineEdit;
    QLineEdit *k5LineEdit;
    QLineEdit *k6LineEdit;
    QLineEdit *k7LineEdit;
    QLineEdit *k8LineEdit;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_16;
    QPushButton *QueryCodePushButton;
    QPushButton *clearrecPushButton;
    QSpacerItem *horizontalSpacer_22;
    QGroupBox *groupBox_2;
    QTextEdit *keyTextEdit;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_18;
    QPushButton *queryclearPushButton;
    QSpacerItem *horizontalSpacer_24;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_17;
    QPushButton *getPushButton;
    QSpacerItem *horizontalSpacer_23;
    QGroupBox *groupBox_4;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_9;
    QLineEdit *pidLineEdit;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_10;
    QLineEdit *vidLineEdit;
    QFrame *line;
    QFrame *line_3;
    QSpacerItem *verticalSpacer_9;
    QSpacerItem *horizontalSpacer_13;
    QSpacerItem *verticalSpacer_10;
    QSpacerItem *horizontalSpacer_14;
    QWidget *tab_8;
    QGridLayout *gridLayout_7;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_16;
    QLabel *label_5;
    QLineEdit *mousePos;
    QSpacerItem *horizontalSpacer_17;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *leftButton;
    QPushButton *midButton;
    QPushButton *rightButton;
    QSpacerItem *horizontalSpacer_12;
    QSpacerItem *verticalSpacer_6;
    QSpacerItem *verticalSpacer_7;
    QWidget *tab_11;
    QGridLayout *gridLayout_13;
    QTextEdit *textEdit_4;
    QLabel *label_2;
    QWidget *tab;
    QGridLayout *gridLayout_4;
    QSpacerItem *verticalSpacer_18;
    QGroupBox *groupBox;
    QPushButton *deletePushButton;
    QPushButton *upPushButton;
    QPushButton *titlePushButton;
    QPushButton *EscPushButton;
    QPushButton *twoRightPushButton;
    QPushButton *rightDivisionPushButton;
    QPushButton *zeroUpPushButton;
    QPushButton *sevenRightPushButton;
    QPushButton *threeUpPushButton;
    QPushButton *sixUpPushButton;
    QPushButton *ctrlRightPushButton;
    QPushButton *jianPushButton;
    QPushButton *ePushButton;
    QPushButton *vPushButton;
    QPushButton *jiaPushButton;
    QPushButton *F8PushButton;
    QPushButton *jPushButton;
    QPushButton *bPushButton;
    QPushButton *sPushButton;
    QPushButton *questionPushButtom;
    QPushButton *shiftLeftPushButton;
    QPushButton *F3PushButton;
    QPushButton *oPushButton;
    QPushButton *nineRightPushButton;
    QPushButton *pPushButton;
    QPushButton *xPushButton;
    QPushButton *nPushButton;
    QPushButton *enterRightPushButton;
    QPushButton *altLeftPushButton;
    QPushButton *oneUpPushButton;
    QPushButton *oneRightPushButton;
    QPushButton *insertPushButton;
    QPushButton *windowsLeftPushButton;
    QPushButton *spacePushButton;
    QPushButton *F2PushButton;
    QPushButton *eightUpPushButton;
    QPushButton *key1PushButton;
    QPushButton *leftPushButton;
    QPushButton *F10PushButton;
    QPushButton *rightMulPushButton;
    QPushButton *zPushButton;
    QPushButton *F6PushButton;
    QPushButton *fiveRightPushButton;
    QPushButton *aPushButton;
    QPushButton *NumLockPushButton;
    QPushButton *pageUpPushButton;
    QPushButton *enterLeftPushButton;
    QPushButton *F12PushButton;
    QPushButton *semicolonPushButton;
    QPushButton *F9PushButton;
    QPushButton *downPushButton;
    QPushButton *kPushButton;
    QPushButton *fPushButton;
    QPushButton *iPushButton;
    QPushButton *zeroRightPushButton;
    QPushButton *F1PushButton;
    QPushButton *commaPushButton;
    QPushButton *fiveUpPushButton;
    QPushButton *leftBracketPushButton;
    QPushButton *ScrollLockPushButton;
    QPushButton *F5PushButton;
    QPushButton *fourRightPushButton;
    QPushButton *rightSubPushButton;
    QPushButton *twoUpPushButton;
    QPushButton *tabPushButton;
    QPushButton *gPushButton;
    QPushButton *PauseBreakPushButton;
    QPushButton *threeRightPushButton;
    QPushButton *nineUpPushButton;
    QPushButton *sevenUpPushButton;
    QPushButton *qPushButton;
    QPushButton *windowsRightPushButton;
    QPushButton *F7PushButton;
    QPushButton *lPushButton;
    QPushButton *rPushButton;
    QPushButton *F4PushButton;
    QPushButton *cPushButton;
    QPushButton *ctrlLeftPushButton;
    QPushButton *spotPushButton;
    QPushButton *rightPushButton;
    QPushButton *yPushButton;
    QPushButton *homePushButton;
    QPushButton *pageDownPushButton;
    QPushButton *tPushButton;
    QPushButton *F11PushButton;
    QPushButton *shiftRightPushButton;
    QPushButton *hPushButton;
    QPushButton *dPushButton;
    QPushButton *altRightPushButton;
    QPushButton *delRightPushButton;
    QPushButton *rightBracketPushButton;
    QPushButton *sixRightPushButton;
    QPushButton *capsLockPushButton;
    QPushButton *wPushButton;
    QPushButton *mPushButton;
    QPushButton *uPushButton;
    QPushButton *endPushButton;
    QPushButton *key2PushButton;
    QPushButton *fourUpPushButton;
    QLabel *label;
    QPushButton *eightRightPushButton;
    QPushButton *jiaRightPushButton;
    QPushButton *PrintScreenPushButton;
    QPushButton *backPushButton;
    QPushButton *colonPushButton;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer_17;
    QWidget *tab_10;
    QComboBox *comboBox;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(1829, 796);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Widget->sizePolicy().hasHeightForWidth());
        Widget->setSizePolicy(sizePolicy);
        Widget->setFocusPolicy(Qt::NoFocus);
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/resources/title.ico"), QSize(), QIcon::Normal, QIcon::Off);
        Widget->setWindowIcon(icon);
        Widget->setStyleSheet(QLatin1String("QWidget.SideBar {    \n"
"	border-right: 1px solid rgb(33, 135, 198);    /* # */\n"
"	border-left: none;\n"
"	background: qlineargradient(spread:reflect,\n"
"    x1:0, y1:0, x2:1, y2:0,\n"
"	stop:0 rgba(22, 89, 131, 255),\n"
"	stop:1 rgba(25, 100, 148, 255));\n"
"    \n"
"/*stop:0 rgba(16, 68, 100, 255),  /* 1c7183 color: rgb(16, 68, 100);*/\n"
"	\n"
"/*    stop:1 rgba(28, 113, 166, 255));  /* 165983 */\n"
"}\n"
"\n"
"QWidget.test {    \n"
"	border-left: 1px solid rgb(33, 135, 198);    /* #196494 */\n"
"	border-right: none;\n"
"	\n"
"/*	background-color: rgb(255, 249, 179); */\n"
"	background: qlineargradient(spread:reflect,\n"
"    x1:0, y1:0, x2:1, y2:0,\n"
"	stop:0 rgba(25, 100, 148, 255),\n"
"	stop:1 rgba(22, 89, 131, 255));\n"
"    \n"
"/*stop:0 rgba(16, 68, 100, 255),  /* 1c7183 color: rgb(16, 68, 100);*/\n"
"	\n"
"/*    stop:1 rgba(28, 113, 166, 255));  /* 165983 */\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb"
                        "(240,240,240);\n"
"\n"
"    padding-left:5px;\n"
"    padding-right: 5px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[current=\"true\"] {\n"
"    border-top: 1px solid rgb(90,90,90);\n"
"    border-right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}\n"
"\n"
"QWidget.SideBar .Separator {\n"
"    border: none;\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"    stop:0 rg"
                        "ba(48, 199, 229, 255),  /*   rgb(34, 138, 202) color: rgb(13, 59, 88); */\n"
"    stop:1 rgba(8, 35, 40, 255));  /* 1c7183   rgbrgb(33, 140, 161)(20, 82, 95) */\n"
"\n"
"}\n"
"\n"
"QTabWidget::pane {\n"
"    border-right: 1px solid rgb(23, 95, 140);\n"
"	\n"
"	background-color: rgb(19, 84, 136);\n"
"/*    background: qlineargradient(spread:pad,  /*reflect pad */\n"
"/*        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(22, 89, 131, 255),\n"
"		stop:1 rgba(25, 100, 148, 255));\n"
"/*	\n"
"	rgb(19, 84, 136)\n"
"	color: rgb(25, 103, 171); 1967ab\n"
"	color: rgb(25, 100, 148); \n"
"	color: rgb(22, 89, 131);\n"
"	color: rgb(34, 29, 62);\n"
"	color: rgb(103, 88, 188);\n"
"	stop:0 rgba(35, 35, 35, 255),\n"
"		stop:1 rgba(150, 150, 150, 255));\n"
"	color: rgb(44, 61, 102);\n"
"	color: rgb(110, 154, 255);   \n"
"*/\n"
"}\n"
"\n"
"QWidget.test QPushButton {\n"
"	color: white;\n"
"    border-right: 1px solid rgb(170, 170, 170);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
""
                        "        stop:0 rgba(22, 89, 131, 255),\n"
"		stop:1 rgba(30, 105, 160, 255));\n"
"    border-width: 2px;\n"
"    border-color: rgb(150, 150, 150);\n"
"    border-style: inset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"\n"
"    padding-left:5px;\n"
"    padding-right: 5px;\n"
"    padding-top: 5px;\n"
"    \n"
"	min-width: 9ex;\n"
"    min-height: 2.5ex;\n"
"}\n"
"\n"
"QWidget.test QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QWidget.test QPushButton[current=\"true\"] {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
""));
        gridLayout = new QGridLayout(Widget);
        gridLayout->setSpacing(0);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        test = new QWidget(Widget);
        test->setObjectName(QStringLiteral("test"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(test->sizePolicy().hasHeightForWidth());
        test->setSizePolicy(sizePolicy1);
        test->setMinimumSize(QSize(130, 0));
        test->setMaximumSize(QSize(130, 16777215));
        test->setStyleSheet(QLatin1String("/**\n"
"QWidget {    \n"
"	border-left: none;\n"
"	border-right: 1px solid rgb(25, 100, 148);    /* #196494 \n"
"	background: qlineargradient(spread:reflect,\n"
"    x1:0, y1:0, x2:1, y2:0,\n"
"	\n"
"	stop:0 rgba(25, 100, 148, 255),\n"
"	stop:1 rgba(22, 89, 131, 255));\n"
"/*    stop:0 rgba(16, 68, 100, 255)   /* 165983 \n"
"/*    stop:1 rgba(28, 113, 166, 255)); /* 1c7183 color: rgb(16, 68, 100);\n"
"}\n"
"****************************/"));
        gridLayout_12 = new QGridLayout(test);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        gridLayout_12->setVerticalSpacing(12);
        gridLayout_12->setContentsMargins(10, -1, 10, 10);
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_18);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        errorLabel_2 = new QLabel(test);
        errorLabel_2->setObjectName(QStringLiteral("errorLabel_2"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(errorLabel_2->sizePolicy().hasHeightForWidth());
        errorLabel_2->setSizePolicy(sizePolicy2);
        QFont font;
        font.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        errorLabel_2->setFont(font);

        verticalLayout->addWidget(errorLabel_2);

        errorCnt = new QLabel(test);
        errorCnt->setObjectName(QStringLiteral("errorCnt"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        font1.setPointSize(10);
        errorCnt->setFont(font1);
        errorCnt->setStyleSheet(QStringLiteral("color: rgb(234, 234, 234);"));
        errorCnt->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(errorCnt);

        timeLabel = new QLabel(test);
        timeLabel->setObjectName(QStringLiteral("timeLabel"));
        sizePolicy2.setHeightForWidth(timeLabel->sizePolicy().hasHeightForWidth());
        timeLabel->setSizePolicy(sizePolicy2);
        QFont font2;
        font2.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setWeight(75);
        timeLabel->setFont(font2);

        verticalLayout->addWidget(timeLabel);

        timeCnt = new QLabel(test);
        timeCnt->setObjectName(QStringLiteral("timeCnt"));
        timeCnt->setFont(font1);
        timeCnt->setStyleSheet(QStringLiteral("color: rgb(234, 234, 234);"));
        timeCnt->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(timeCnt);

        errorLabel = new QLabel(test);
        errorLabel->setObjectName(QStringLiteral("errorLabel"));
        sizePolicy2.setHeightForWidth(errorLabel->sizePolicy().hasHeightForWidth());
        errorLabel->setSizePolicy(sizePolicy2);
        errorLabel->setFont(font2);

        verticalLayout->addWidget(errorLabel);

        circleCnt = new QLabel(test);
        circleCnt->setObjectName(QStringLiteral("circleCnt"));
        circleCnt->setFont(font1);
        circleCnt->setStyleSheet(QStringLiteral("color: rgb(234, 234, 234);"));
        circleCnt->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(circleCnt);


        horizontalLayout_12->addLayout(verticalLayout);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_19);


        gridLayout_12->addLayout(horizontalLayout_12, 8, 0, 1, 1);

        verticalSpacer_15 = new QSpacerItem(0, 110, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_12->addItem(verticalSpacer_15, 0, 0, 1, 1);

        circleButton = new QPushButton(test);
        circleButton->setObjectName(QStringLiteral("circleButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(circleButton->sizePolicy().hasHeightForWidth());
        circleButton->setSizePolicy(sizePolicy3);
        circleButton->setMinimumSize(QSize(77, 30));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(9);
        font3.setBold(true);
        font3.setWeight(75);
        circleButton->setFont(font3);

        gridLayout_12->addWidget(circleButton, 2, 0, 1, 1);

        deleteLogButton = new QPushButton(test);
        deleteLogButton->setObjectName(QStringLiteral("deleteLogButton"));
        sizePolicy3.setHeightForWidth(deleteLogButton->sizePolicy().hasHeightForWidth());
        deleteLogButton->setSizePolicy(sizePolicy3);
        deleteLogButton->setMinimumSize(QSize(77, 30));
        deleteLogButton->setFont(font3);

        gridLayout_12->addWidget(deleteLogButton, 5, 0, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout_12->addItem(verticalSpacer_8, 10, 0, 1, 1);

        label_7 = new QLabel(test);
        label_7->setObjectName(QStringLiteral("label_7"));
        sizePolicy3.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy3);
        label_7->setMaximumSize(QSize(110, 210));
        label_7->setTextFormat(Qt::RichText);
        label_7->setPixmap(QPixmap(QString::fromUtf8(":/images/resources/title2.png")));
        label_7->setScaledContents(true);
        label_7->setMargin(10);

        gridLayout_12->addWidget(label_7, 11, 0, 1, 1);

        verticalSpacer_16 = new QSpacerItem(20, 15, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_12->addItem(verticalSpacer_16, 6, 0, 1, 1);

        checkLogButton = new QPushButton(test);
        checkLogButton->setObjectName(QStringLiteral("checkLogButton"));
        sizePolicy3.setHeightForWidth(checkLogButton->sizePolicy().hasHeightForWidth());
        checkLogButton->setSizePolicy(sizePolicy3);
        checkLogButton->setMinimumSize(QSize(77, 30));
        checkLogButton->setFont(font3);

        gridLayout_12->addWidget(checkLogButton, 4, 0, 1, 1);


        gridLayout->addWidget(test, 0, 4, 1, 1);

        SideBar = new QWidget(Widget);
        SideBar->setObjectName(QStringLiteral("SideBar"));
        sizePolicy1.setHeightForWidth(SideBar->sizePolicy().hasHeightForWidth());
        SideBar->setSizePolicy(sizePolicy1);
        SideBar->setMinimumSize(QSize(120, 0));
        gridLayout_2 = new QGridLayout(SideBar);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(SideBar);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setMinimumSize(QSize(0, 1));
        widget->setMaximumSize(QSize(16777215, 1));

        gridLayout_2->addWidget(widget, 6, 1, 1, 1);

        toolButton_kbdlite = new QToolButton(SideBar);
        toolButton_kbdlite->setObjectName(QStringLiteral("toolButton_kbdlite"));
        sizePolicy3.setHeightForWidth(toolButton_kbdlite->sizePolicy().hasHeightForWidth());
        toolButton_kbdlite->setSizePolicy(sizePolicy3);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/images/resources/RUN-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_kbdlite->setIcon(icon1);
        toolButton_kbdlite->setIconSize(QSize(64, 50));
        toolButton_kbdlite->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_kbdlite, 8, 1, 1, 1);

        toolButton_mouse = new QToolButton(SideBar);
        toolButton_mouse->setObjectName(QStringLiteral("toolButton_mouse"));
        sizePolicy3.setHeightForWidth(toolButton_mouse->sizePolicy().hasHeightForWidth());
        toolButton_mouse->setSizePolicy(sizePolicy3);
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/resources/Mouse.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_mouse->setIcon(icon2);
        toolButton_mouse->setIconSize(QSize(64, 50));
        toolButton_mouse->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_mouse, 9, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 10, 1, 1, 1);

        toolButton_kbd = new QToolButton(SideBar);
        toolButton_kbd->setObjectName(QStringLiteral("toolButton_kbd"));
        sizePolicy3.setHeightForWidth(toolButton_kbd->sizePolicy().hasHeightForWidth());
        toolButton_kbd->setSizePolicy(sizePolicy3);
        toolButton_kbd->setFocusPolicy(Qt::TabFocus);
        toolButton_kbd->setLayoutDirection(Qt::LeftToRight);
        toolButton_kbd->setAutoFillBackground(false);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/images/resources/keyboard.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_kbd->setIcon(icon3);
        toolButton_kbd->setIconSize(QSize(64, 54));
        toolButton_kbd->setCheckable(false);
        toolButton_kbd->setAutoRepeat(false);
        toolButton_kbd->setPopupMode(QToolButton::DelayedPopup);
        toolButton_kbd->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        toolButton_kbd->setAutoRaise(false);
        toolButton_kbd->setArrowType(Qt::NoArrow);

        gridLayout_2->addWidget(toolButton_kbd, 7, 1, 1, 1);

        toolButton_ram = new QToolButton(SideBar);
        toolButton_ram->setObjectName(QStringLiteral("toolButton_ram"));
        sizePolicy3.setHeightForWidth(toolButton_ram->sizePolicy().hasHeightForWidth());
        toolButton_ram->setSizePolicy(sizePolicy3);
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/images/resources/button-1.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_ram->setIcon(icon4);
        toolButton_ram->setIconSize(QSize(64, 54));
        toolButton_ram->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_ram, 1, 1, 1, 1);

        toolButton_disk = new QToolButton(SideBar);
        toolButton_disk->setObjectName(QStringLiteral("toolButton_disk"));
        sizePolicy3.setHeightForWidth(toolButton_disk->sizePolicy().hasHeightForWidth());
        toolButton_disk->setSizePolicy(sizePolicy3);
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/images/resources/button-2.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_disk->setIcon(icon5);
        toolButton_disk->setIconSize(QSize(64, 54));
        toolButton_disk->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_disk, 2, 1, 1, 1);

        toolButton_pic = new QToolButton(SideBar);
        toolButton_pic->setObjectName(QStringLiteral("toolButton_pic"));
        sizePolicy3.setHeightForWidth(toolButton_pic->sizePolicy().hasHeightForWidth());
        toolButton_pic->setSizePolicy(sizePolicy3);
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/images/resources/button-3.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_pic->setIcon(icon6);
        toolButton_pic->setIconSize(QSize(64, 54));
        toolButton_pic->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_pic, 3, 1, 1, 1);

        toolButton_net = new QToolButton(SideBar);
        toolButton_net->setObjectName(QStringLiteral("toolButton_net"));
        sizePolicy3.setHeightForWidth(toolButton_net->sizePolicy().hasHeightForWidth());
        toolButton_net->setSizePolicy(sizePolicy3);
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/images/resources/button-4.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_net->setIcon(icon7);
        toolButton_net->setIconSize(QSize(64, 54));
        toolButton_net->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_net, 4, 1, 1, 1);

        toolButton_uart = new QToolButton(SideBar);
        toolButton_uart->setObjectName(QStringLiteral("toolButton_uart"));
        sizePolicy3.setHeightForWidth(toolButton_uart->sizePolicy().hasHeightForWidth());
        toolButton_uart->setSizePolicy(sizePolicy3);
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/images/resources/button-5.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_uart->setIcon(icon8);
        toolButton_uart->setIconSize(QSize(64, 54));
        toolButton_uart->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        gridLayout_2->addWidget(toolButton_uart, 5, 1, 1, 1);

        checkBox1 = new QCheckBox(SideBar);
        checkBox1->setObjectName(QStringLiteral("checkBox1"));
        checkBox1->setStyleSheet(QStringLiteral(""));

        gridLayout_2->addWidget(checkBox1, 1, 2, 1, 1);

        checkBox2 = new QCheckBox(SideBar);
        checkBox2->setObjectName(QStringLiteral("checkBox2"));

        gridLayout_2->addWidget(checkBox2, 2, 2, 1, 1);

        checkBox3 = new QCheckBox(SideBar);
        checkBox3->setObjectName(QStringLiteral("checkBox3"));

        gridLayout_2->addWidget(checkBox3, 3, 2, 1, 1);

        checkBox4 = new QCheckBox(SideBar);
        checkBox4->setObjectName(QStringLiteral("checkBox4"));

        gridLayout_2->addWidget(checkBox4, 4, 2, 1, 1);

        checkBox5 = new QCheckBox(SideBar);
        checkBox5->setObjectName(QStringLiteral("checkBox5"));

        gridLayout_2->addWidget(checkBox5, 5, 2, 1, 1);


        gridLayout->addWidget(SideBar, 0, 1, 1, 1);

        testWidget = new QTabWidget(Widget);
        testWidget->setObjectName(QStringLiteral("testWidget"));
        testWidget->setStyleSheet(QStringLiteral(""));
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        tab_6->setStyleSheet(QLatin1String("QPushButton {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                        stop: 0 #f6f7fa, stop: 1 #dadbde);\n"
"    border-width: 2px;\n"
"    border-color: rgb(187, 188, 190);\n"
"    border-style: inset;\n"
"\n"
"    padding: 3px;\n"
"    border: 2px solid #9c9c9d;\n"
"    border-radius: 6px;\n"
"}\n"
"/*\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"*/\n"
"QPushButton:flat {\n"
"    border: none; /* no border for a flat push button */\n"
"}\n"
"\n"
"QPushButton:default {\n"
"    border-color: navy; /* make the default button prominent */\n"
"}\n"
"\n"
"QPushButton[current=\"true\"] {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(0, 224, 121);  /* 0, 224, 121 21a675 255, 89, 97 */\n"
"}\n"
"\n"
"QPushButton[first=\"true\"] {\n"
"    border-top: 1px dashed "
                        "rgba(0, 0, 0, 0);\n"
"}\n"
"/***\n"
"QPushButton {\n"
"    background-color: rgb(221, 221, 221);\n"
"    border-width: 2px;\n"
"    border-color: rgb(194, 194, 194);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"    min-width: 9ex;\n"
"    min-height: 2.5ex;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"\n"
"QPushButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb(240,240,240);\n"
"\n"
"    padding-left:12px;\n"
"    padding-right: 12px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QPushButton[current=\"true\"] {\n"
"    border-top: 1px"
                        " solid rgb(90,90,90);\n"
"    border-right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QPushButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}*/"));
        gridLayout_6 = new QGridLayout(tab_6);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        gridLayout_6->setVerticalSpacing(10);
        gridLayout_6->setContentsMargins(20, -1, 40, -1);
        verticalSpacer_4 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_6->addItem(verticalSpacer_4, 0, 1, 1, 1);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setSpacing(60);
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        horizontalLayout_36->setContentsMargins(0, -1, 40, -1);
        pushButton1 = new QPushButton(tab_6);
        pushButton1->setObjectName(QStringLiteral("pushButton1"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(20);
        sizePolicy4.setVerticalStretch(20);
        sizePolicy4.setHeightForWidth(pushButton1->sizePolicy().hasHeightForWidth());
        pushButton1->setSizePolicy(sizePolicy4);
        pushButton1->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton1);

        pushButton2 = new QPushButton(tab_6);
        pushButton2->setObjectName(QStringLiteral("pushButton2"));
        sizePolicy4.setHeightForWidth(pushButton2->sizePolicy().hasHeightForWidth());
        pushButton2->setSizePolicy(sizePolicy4);
        pushButton2->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton2);

        pushButton3 = new QPushButton(tab_6);
        pushButton3->setObjectName(QStringLiteral("pushButton3"));
        sizePolicy4.setHeightForWidth(pushButton3->sizePolicy().hasHeightForWidth());
        pushButton3->setSizePolicy(sizePolicy4);
        pushButton3->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton3);

        pushButton4 = new QPushButton(tab_6);
        pushButton4->setObjectName(QStringLiteral("pushButton4"));
        sizePolicy4.setHeightForWidth(pushButton4->sizePolicy().hasHeightForWidth());
        pushButton4->setSizePolicy(sizePolicy4);
        pushButton4->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton4);

        pushButton5 = new QPushButton(tab_6);
        pushButton5->setObjectName(QStringLiteral("pushButton5"));
        sizePolicy4.setHeightForWidth(pushButton5->sizePolicy().hasHeightForWidth());
        pushButton5->setSizePolicy(sizePolicy4);
        pushButton5->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton5);

        pushButton6 = new QPushButton(tab_6);
        pushButton6->setObjectName(QStringLiteral("pushButton6"));
        sizePolicy4.setHeightForWidth(pushButton6->sizePolicy().hasHeightForWidth());
        pushButton6->setSizePolicy(sizePolicy4);
        pushButton6->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton6);

        pushButton7 = new QPushButton(tab_6);
        pushButton7->setObjectName(QStringLiteral("pushButton7"));
        sizePolicy4.setHeightForWidth(pushButton7->sizePolicy().hasHeightForWidth());
        pushButton7->setSizePolicy(sizePolicy4);
        pushButton7->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton7);

        pushButton8 = new QPushButton(tab_6);
        pushButton8->setObjectName(QStringLiteral("pushButton8"));
        sizePolicy4.setHeightForWidth(pushButton8->sizePolicy().hasHeightForWidth());
        pushButton8->setSizePolicy(sizePolicy4);
        pushButton8->setMinimumSize(QSize(100, 80));

        horizontalLayout_36->addWidget(pushButton8);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_2);


        gridLayout_6->addLayout(horizontalLayout_36, 3, 1, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout_6->addItem(verticalSpacer_5, 9, 1, 1, 1);

        label_13 = new QLabel(tab_6);
        label_13->setObjectName(QStringLiteral("label_13"));
        QFont font4;
        font4.setFamily(QString::fromUtf8("\346\226\271\346\255\243\346\245\267\344\275\223"));
        font4.setBold(true);
        font4.setWeight(75);
        label_13->setFont(font4);

        gridLayout_6->addWidget(label_13, 2, 1, 1, 1);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_6->addItem(horizontalSpacer_10, 4, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_6->addItem(horizontalSpacer, 4, 0, 1, 1);

        label_14 = new QLabel(tab_6);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setFont(font4);

        gridLayout_6->addWidget(label_14, 1, 1, 1, 1);

        horizontalLayout_49 = new QHBoxLayout();
        horizontalLayout_49->setSpacing(60);
        horizontalLayout_49->setObjectName(QStringLiteral("horizontalLayout_49"));
        horizontalLayout_49->setContentsMargins(0, -1, 40, -1);
        pushButton_111 = new QPushButton(tab_6);
        pushButton_111->setObjectName(QStringLiteral("pushButton_111"));
        sizePolicy.setHeightForWidth(pushButton_111->sizePolicy().hasHeightForWidth());
        pushButton_111->setSizePolicy(sizePolicy);
        pushButton_111->setMinimumSize(QSize(120, 100));
        pushButton_111->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_111->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_111);

        pushButton_112 = new QPushButton(tab_6);
        pushButton_112->setObjectName(QStringLiteral("pushButton_112"));
        sizePolicy.setHeightForWidth(pushButton_112->sizePolicy().hasHeightForWidth());
        pushButton_112->setSizePolicy(sizePolicy);
        pushButton_112->setMinimumSize(QSize(120, 100));
        pushButton_112->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_112->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_112);

        pushButton_113 = new QPushButton(tab_6);
        pushButton_113->setObjectName(QStringLiteral("pushButton_113"));
        sizePolicy.setHeightForWidth(pushButton_113->sizePolicy().hasHeightForWidth());
        pushButton_113->setSizePolicy(sizePolicy);
        pushButton_113->setMinimumSize(QSize(120, 100));
        pushButton_113->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_113->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_113);

        pushButton_114 = new QPushButton(tab_6);
        pushButton_114->setObjectName(QStringLiteral("pushButton_114"));
        sizePolicy.setHeightForWidth(pushButton_114->sizePolicy().hasHeightForWidth());
        pushButton_114->setSizePolicy(sizePolicy);
        pushButton_114->setMinimumSize(QSize(120, 100));
        pushButton_114->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_114->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_114);

        pushButton_115 = new QPushButton(tab_6);
        pushButton_115->setObjectName(QStringLiteral("pushButton_115"));
        sizePolicy.setHeightForWidth(pushButton_115->sizePolicy().hasHeightForWidth());
        pushButton_115->setSizePolicy(sizePolicy);
        pushButton_115->setMinimumSize(QSize(120, 100));
        pushButton_115->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_115->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_115);

        pushButton_116 = new QPushButton(tab_6);
        pushButton_116->setObjectName(QStringLiteral("pushButton_116"));
        sizePolicy.setHeightForWidth(pushButton_116->sizePolicy().hasHeightForWidth());
        pushButton_116->setSizePolicy(sizePolicy);
        pushButton_116->setMinimumSize(QSize(120, 100));
        pushButton_116->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_116->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_116);

        pushButton_117 = new QPushButton(tab_6);
        pushButton_117->setObjectName(QStringLiteral("pushButton_117"));
        sizePolicy.setHeightForWidth(pushButton_117->sizePolicy().hasHeightForWidth());
        pushButton_117->setSizePolicy(sizePolicy);
        pushButton_117->setMinimumSize(QSize(120, 100));
        pushButton_117->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_117->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_117);

        pushButton_118 = new QPushButton(tab_6);
        pushButton_118->setObjectName(QStringLiteral("pushButton_118"));
        sizePolicy.setHeightForWidth(pushButton_118->sizePolicy().hasHeightForWidth());
        pushButton_118->setSizePolicy(sizePolicy);
        pushButton_118->setMinimumSize(QSize(120, 100));
        pushButton_118->setStyleSheet(QStringLiteral("background: transparent;"));
        pushButton_118->setFlat(true);

        horizontalLayout_49->addWidget(pushButton_118);

        horizontalSpacer_26 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_49->addItem(horizontalSpacer_26);


        gridLayout_6->addLayout(horizontalLayout_49, 8, 1, 1, 1);

        horizontalLayout_41 = new QHBoxLayout();
        horizontalLayout_41->setSpacing(60);
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        horizontalLayout_41->setContentsMargins(0, -1, 40, -1);
        pushButton9 = new QPushButton(tab_6);
        pushButton9->setObjectName(QStringLiteral("pushButton9"));
        sizePolicy4.setHeightForWidth(pushButton9->sizePolicy().hasHeightForWidth());
        pushButton9->setSizePolicy(sizePolicy4);
        pushButton9->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton9);

        pushButton10 = new QPushButton(tab_6);
        pushButton10->setObjectName(QStringLiteral("pushButton10"));
        sizePolicy4.setHeightForWidth(pushButton10->sizePolicy().hasHeightForWidth());
        pushButton10->setSizePolicy(sizePolicy4);
        pushButton10->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton10);

        pushButton11 = new QPushButton(tab_6);
        pushButton11->setObjectName(QStringLiteral("pushButton11"));
        sizePolicy4.setHeightForWidth(pushButton11->sizePolicy().hasHeightForWidth());
        pushButton11->setSizePolicy(sizePolicy4);
        pushButton11->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton11);

        pushButton12 = new QPushButton(tab_6);
        pushButton12->setObjectName(QStringLiteral("pushButton12"));
        sizePolicy4.setHeightForWidth(pushButton12->sizePolicy().hasHeightForWidth());
        pushButton12->setSizePolicy(sizePolicy4);
        pushButton12->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton12);

        pushButton13 = new QPushButton(tab_6);
        pushButton13->setObjectName(QStringLiteral("pushButton13"));
        sizePolicy4.setHeightForWidth(pushButton13->sizePolicy().hasHeightForWidth());
        pushButton13->setSizePolicy(sizePolicy4);
        pushButton13->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton13);

        pushButton14 = new QPushButton(tab_6);
        pushButton14->setObjectName(QStringLiteral("pushButton14"));
        sizePolicy4.setHeightForWidth(pushButton14->sizePolicy().hasHeightForWidth());
        pushButton14->setSizePolicy(sizePolicy4);
        pushButton14->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton14);

        pushButton15 = new QPushButton(tab_6);
        pushButton15->setObjectName(QStringLiteral("pushButton15"));
        sizePolicy4.setHeightForWidth(pushButton15->sizePolicy().hasHeightForWidth());
        pushButton15->setSizePolicy(sizePolicy4);
        pushButton15->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton15);

        pushButton16 = new QPushButton(tab_6);
        pushButton16->setObjectName(QStringLiteral("pushButton16"));
        sizePolicy4.setHeightForWidth(pushButton16->sizePolicy().hasHeightForWidth());
        pushButton16->setSizePolicy(sizePolicy4);
        pushButton16->setMinimumSize(QSize(100, 80));

        horizontalLayout_41->addWidget(pushButton16);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_41->addItem(horizontalSpacer_5);


        gridLayout_6->addLayout(horizontalLayout_41, 4, 1, 1, 1);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setSpacing(60);
        horizontalLayout_39->setObjectName(QStringLiteral("horizontalLayout_39"));
        horizontalLayout_39->setContentsMargins(0, -1, 40, -1);
        pushButton25 = new QPushButton(tab_6);
        pushButton25->setObjectName(QStringLiteral("pushButton25"));
        sizePolicy4.setHeightForWidth(pushButton25->sizePolicy().hasHeightForWidth());
        pushButton25->setSizePolicy(sizePolicy4);
        pushButton25->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton25);

        pushButton26 = new QPushButton(tab_6);
        pushButton26->setObjectName(QStringLiteral("pushButton26"));
        sizePolicy4.setHeightForWidth(pushButton26->sizePolicy().hasHeightForWidth());
        pushButton26->setSizePolicy(sizePolicy4);
        pushButton26->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton26);

        pushButton27 = new QPushButton(tab_6);
        pushButton27->setObjectName(QStringLiteral("pushButton27"));
        sizePolicy4.setHeightForWidth(pushButton27->sizePolicy().hasHeightForWidth());
        pushButton27->setSizePolicy(sizePolicy4);
        pushButton27->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton27);

        pushButton28 = new QPushButton(tab_6);
        pushButton28->setObjectName(QStringLiteral("pushButton28"));
        sizePolicy4.setHeightForWidth(pushButton28->sizePolicy().hasHeightForWidth());
        pushButton28->setSizePolicy(sizePolicy4);
        pushButton28->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton28);

        pushButton29 = new QPushButton(tab_6);
        pushButton29->setObjectName(QStringLiteral("pushButton29"));
        sizePolicy4.setHeightForWidth(pushButton29->sizePolicy().hasHeightForWidth());
        pushButton29->setSizePolicy(sizePolicy4);
        pushButton29->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton29);

        pushButton30 = new QPushButton(tab_6);
        pushButton30->setObjectName(QStringLiteral("pushButton30"));
        sizePolicy4.setHeightForWidth(pushButton30->sizePolicy().hasHeightForWidth());
        pushButton30->setSizePolicy(sizePolicy4);
        pushButton30->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton30);

        pushButton31 = new QPushButton(tab_6);
        pushButton31->setObjectName(QStringLiteral("pushButton31"));
        sizePolicy4.setHeightForWidth(pushButton31->sizePolicy().hasHeightForWidth());
        pushButton31->setSizePolicy(sizePolicy4);
        pushButton31->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton31);

        pushButton32 = new QPushButton(tab_6);
        pushButton32->setObjectName(QStringLiteral("pushButton32"));
        sizePolicy4.setHeightForWidth(pushButton32->sizePolicy().hasHeightForWidth());
        pushButton32->setSizePolicy(sizePolicy4);
        pushButton32->setMinimumSize(QSize(100, 80));

        horizontalLayout_39->addWidget(pushButton32);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_39->addItem(horizontalSpacer_7);


        gridLayout_6->addLayout(horizontalLayout_39, 6, 1, 1, 1);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setSpacing(60);
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        horizontalLayout_38->setContentsMargins(0, -1, 40, -1);
        pushButton17 = new QPushButton(tab_6);
        pushButton17->setObjectName(QStringLiteral("pushButton17"));
        sizePolicy4.setHeightForWidth(pushButton17->sizePolicy().hasHeightForWidth());
        pushButton17->setSizePolicy(sizePolicy4);
        pushButton17->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton17);

        pushButton18 = new QPushButton(tab_6);
        pushButton18->setObjectName(QStringLiteral("pushButton18"));
        sizePolicy4.setHeightForWidth(pushButton18->sizePolicy().hasHeightForWidth());
        pushButton18->setSizePolicy(sizePolicy4);
        pushButton18->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton18);

        pushButton19 = new QPushButton(tab_6);
        pushButton19->setObjectName(QStringLiteral("pushButton19"));
        sizePolicy4.setHeightForWidth(pushButton19->sizePolicy().hasHeightForWidth());
        pushButton19->setSizePolicy(sizePolicy4);
        pushButton19->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton19);

        pushButton20 = new QPushButton(tab_6);
        pushButton20->setObjectName(QStringLiteral("pushButton20"));
        sizePolicy4.setHeightForWidth(pushButton20->sizePolicy().hasHeightForWidth());
        pushButton20->setSizePolicy(sizePolicy4);
        pushButton20->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton20);

        pushButton21 = new QPushButton(tab_6);
        pushButton21->setObjectName(QStringLiteral("pushButton21"));
        sizePolicy4.setHeightForWidth(pushButton21->sizePolicy().hasHeightForWidth());
        pushButton21->setSizePolicy(sizePolicy4);
        pushButton21->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton21);

        pushButton22 = new QPushButton(tab_6);
        pushButton22->setObjectName(QStringLiteral("pushButton22"));
        sizePolicy4.setHeightForWidth(pushButton22->sizePolicy().hasHeightForWidth());
        pushButton22->setSizePolicy(sizePolicy4);
        pushButton22->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton22);

        pushButton23 = new QPushButton(tab_6);
        pushButton23->setObjectName(QStringLiteral("pushButton23"));
        sizePolicy4.setHeightForWidth(pushButton23->sizePolicy().hasHeightForWidth());
        pushButton23->setSizePolicy(sizePolicy4);
        pushButton23->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton23);

        pushButton24 = new QPushButton(tab_6);
        pushButton24->setObjectName(QStringLiteral("pushButton24"));
        sizePolicy4.setHeightForWidth(pushButton24->sizePolicy().hasHeightForWidth());
        pushButton24->setSizePolicy(sizePolicy4);
        pushButton24->setMinimumSize(QSize(100, 80));

        horizontalLayout_38->addWidget(pushButton24);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_38->addItem(horizontalSpacer_6);


        gridLayout_6->addLayout(horizontalLayout_38, 5, 1, 1, 1);

        horizontalLayout_51 = new QHBoxLayout();
        horizontalLayout_51->setSpacing(60);
        horizontalLayout_51->setObjectName(QStringLiteral("horizontalLayout_51"));
        horizontalLayout_51->setContentsMargins(0, -1, 40, -1);
        pushButton33 = new QPushButton(tab_6);
        pushButton33->setObjectName(QStringLiteral("pushButton33"));
        sizePolicy4.setHeightForWidth(pushButton33->sizePolicy().hasHeightForWidth());
        pushButton33->setSizePolicy(sizePolicy4);
        pushButton33->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton33);

        pushButton34 = new QPushButton(tab_6);
        pushButton34->setObjectName(QStringLiteral("pushButton34"));
        sizePolicy4.setHeightForWidth(pushButton34->sizePolicy().hasHeightForWidth());
        pushButton34->setSizePolicy(sizePolicy4);
        pushButton34->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton34);

        pushButton35 = new QPushButton(tab_6);
        pushButton35->setObjectName(QStringLiteral("pushButton35"));
        sizePolicy4.setHeightForWidth(pushButton35->sizePolicy().hasHeightForWidth());
        pushButton35->setSizePolicy(sizePolicy4);
        pushButton35->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton35);

        pushButton36 = new QPushButton(tab_6);
        pushButton36->setObjectName(QStringLiteral("pushButton36"));
        sizePolicy4.setHeightForWidth(pushButton36->sizePolicy().hasHeightForWidth());
        pushButton36->setSizePolicy(sizePolicy4);
        pushButton36->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton36);

        pushButton37 = new QPushButton(tab_6);
        pushButton37->setObjectName(QStringLiteral("pushButton37"));
        sizePolicy4.setHeightForWidth(pushButton37->sizePolicy().hasHeightForWidth());
        pushButton37->setSizePolicy(sizePolicy4);
        pushButton37->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton37);

        pushButton38 = new QPushButton(tab_6);
        pushButton38->setObjectName(QStringLiteral("pushButton38"));
        sizePolicy4.setHeightForWidth(pushButton38->sizePolicy().hasHeightForWidth());
        pushButton38->setSizePolicy(sizePolicy4);
        pushButton38->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton38);

        pushButton39 = new QPushButton(tab_6);
        pushButton39->setObjectName(QStringLiteral("pushButton39"));
        sizePolicy4.setHeightForWidth(pushButton39->sizePolicy().hasHeightForWidth());
        pushButton39->setSizePolicy(sizePolicy4);
        pushButton39->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton39);

        pushButton40 = new QPushButton(tab_6);
        pushButton40->setObjectName(QStringLiteral("pushButton40"));
        sizePolicy4.setHeightForWidth(pushButton40->sizePolicy().hasHeightForWidth());
        pushButton40->setSizePolicy(sizePolicy4);
        pushButton40->setMinimumSize(QSize(100, 80));

        horizontalLayout_51->addWidget(pushButton40);

        horizontalSpacer_35 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_51->addItem(horizontalSpacer_35);


        gridLayout_6->addLayout(horizontalLayout_51, 7, 1, 1, 1);

        testWidget->addTab(tab_6, QString());
        label_13->raise();
        label_14->raise();
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        tab_9->setStyleSheet(QLatin1String("QPushButton {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                        stop: 0 #f6f7fa, stop: 1 #dadbde);\n"
"    border-width: 2px;\n"
"    border-color: rgb(187, 188, 190);\n"
"    border-style: outset;\n"
"\n"
"    padding: 3px;\n"
"    border: 2px solid #9c9c9d;\n"
"    border-radius: 6px;\n"
"}\n"
"/*\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"*/\n"
"QPushButton:flat {\n"
"    border: none; /* no border for a flat push button */\n"
"}\n"
"\n"
"QPushButton:default {\n"
"    border-color: navy; /* make the default button prominent */\n"
"}\n"
"\n"
"QPushButton[current=\"true\"] {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(0, 224, 121);\n"
"}\n"
"\n"
"QPushButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}\n"
"/***\n"
""
                        "QPushButton {\n"
"    background-color: rgb(221, 221, 221);\n"
"    border-width: 2px;\n"
"    border-color: rgb(194, 194, 194);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"    min-width: 9ex;\n"
"    min-height: 2.5ex;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"\n"
"QPushButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb(240,240,240);\n"
"\n"
"    padding-left:12px;\n"
"    padding-right: 12px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QPushButton[current=\"true\"] {\n"
"    border-top: 1px solid rgb(90,90,90);\n"
"    border-"
                        "right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QPushButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}*/"));
        gridLayout_11 = new QGridLayout(tab_9);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        gridLayout_11->setContentsMargins(20, 20, 20, -1);
        gridLayout_9 = new QGridLayout();
        gridLayout_9->setSpacing(6);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        gridLayout_9->setVerticalSpacing(8);
        line_5 = new QFrame(tab_9);
        line_5->setObjectName(QStringLiteral("line_5"));
        QSizePolicy sizePolicy5(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(line_5->sizePolicy().hasHeightForWidth());
        line_5->setSizePolicy(sizePolicy5);
        line_5->setMinimumSize(QSize(1220, 50));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        gridLayout_9->addWidget(line_5, 2, 0, 1, 1);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(10);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        label_16 = new QLabel(tab_9);
        label_16->setObjectName(QStringLiteral("label_16"));
        QFont font5;
        font5.setFamily(QString::fromUtf8("\346\226\271\346\255\243\346\245\267\344\275\223"));
        font5.setPointSize(14);
        font5.setBold(true);
        font5.setWeight(75);
        label_16->setFont(font5);

        verticalLayout_6->addWidget(label_16);

        horizontalLayout_47 = new QHBoxLayout();
        horizontalLayout_47->setSpacing(60);
        horizontalLayout_47->setObjectName(QStringLiteral("horizontalLayout_47"));
        horizontalLayout_47->setContentsMargins(0, -1, 40, -1);
        pushButton_95 = new QPushButton(tab_9);
        pushButton_95->setObjectName(QStringLiteral("pushButton_95"));
        QSizePolicy sizePolicy6(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(pushButton_95->sizePolicy().hasHeightForWidth());
        pushButton_95->setSizePolicy(sizePolicy6);
        pushButton_95->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_95);

        pushButton_96 = new QPushButton(tab_9);
        pushButton_96->setObjectName(QStringLiteral("pushButton_96"));
        sizePolicy6.setHeightForWidth(pushButton_96->sizePolicy().hasHeightForWidth());
        pushButton_96->setSizePolicy(sizePolicy6);
        pushButton_96->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_96);

        pushButton_97 = new QPushButton(tab_9);
        pushButton_97->setObjectName(QStringLiteral("pushButton_97"));
        sizePolicy6.setHeightForWidth(pushButton_97->sizePolicy().hasHeightForWidth());
        pushButton_97->setSizePolicy(sizePolicy6);
        pushButton_97->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_97);

        pushButton_98 = new QPushButton(tab_9);
        pushButton_98->setObjectName(QStringLiteral("pushButton_98"));
        sizePolicy6.setHeightForWidth(pushButton_98->sizePolicy().hasHeightForWidth());
        pushButton_98->setSizePolicy(sizePolicy6);
        pushButton_98->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_98);

        pushButton_99 = new QPushButton(tab_9);
        pushButton_99->setObjectName(QStringLiteral("pushButton_99"));
        sizePolicy6.setHeightForWidth(pushButton_99->sizePolicy().hasHeightForWidth());
        pushButton_99->setSizePolicy(sizePolicy6);
        pushButton_99->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_99);

        pushButton_100 = new QPushButton(tab_9);
        pushButton_100->setObjectName(QStringLiteral("pushButton_100"));
        sizePolicy6.setHeightForWidth(pushButton_100->sizePolicy().hasHeightForWidth());
        pushButton_100->setSizePolicy(sizePolicy6);
        pushButton_100->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_100);

        pushButton_101 = new QPushButton(tab_9);
        pushButton_101->setObjectName(QStringLiteral("pushButton_101"));
        sizePolicy6.setHeightForWidth(pushButton_101->sizePolicy().hasHeightForWidth());
        pushButton_101->setSizePolicy(sizePolicy6);
        pushButton_101->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_101);

        pushButton_102 = new QPushButton(tab_9);
        pushButton_102->setObjectName(QStringLiteral("pushButton_102"));
        sizePolicy6.setHeightForWidth(pushButton_102->sizePolicy().hasHeightForWidth());
        pushButton_102->setSizePolicy(sizePolicy6);
        pushButton_102->setMinimumSize(QSize(100, 80));

        horizontalLayout_47->addWidget(pushButton_102);

        horizontalSpacer_31 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_47->addItem(horizontalSpacer_31);


        verticalLayout_6->addLayout(horizontalLayout_47);

        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setSpacing(60);
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        horizontalLayout_42->setContentsMargins(0, -1, 40, -1);
        pushButton_41 = new QPushButton(tab_9);
        pushButton_41->setObjectName(QStringLiteral("pushButton_41"));
        sizePolicy6.setHeightForWidth(pushButton_41->sizePolicy().hasHeightForWidth());
        pushButton_41->setSizePolicy(sizePolicy6);
        pushButton_41->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_41);

        pushButton_42 = new QPushButton(tab_9);
        pushButton_42->setObjectName(QStringLiteral("pushButton_42"));
        sizePolicy6.setHeightForWidth(pushButton_42->sizePolicy().hasHeightForWidth());
        pushButton_42->setSizePolicy(sizePolicy6);
        pushButton_42->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_42);

        pushButton_43 = new QPushButton(tab_9);
        pushButton_43->setObjectName(QStringLiteral("pushButton_43"));
        sizePolicy6.setHeightForWidth(pushButton_43->sizePolicy().hasHeightForWidth());
        pushButton_43->setSizePolicy(sizePolicy6);
        pushButton_43->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_43);

        pushButton_44 = new QPushButton(tab_9);
        pushButton_44->setObjectName(QStringLiteral("pushButton_44"));
        sizePolicy6.setHeightForWidth(pushButton_44->sizePolicy().hasHeightForWidth());
        pushButton_44->setSizePolicy(sizePolicy6);
        pushButton_44->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_44);

        pushButton_45 = new QPushButton(tab_9);
        pushButton_45->setObjectName(QStringLiteral("pushButton_45"));
        sizePolicy6.setHeightForWidth(pushButton_45->sizePolicy().hasHeightForWidth());
        pushButton_45->setSizePolicy(sizePolicy6);
        pushButton_45->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_45);

        pushButton_46 = new QPushButton(tab_9);
        pushButton_46->setObjectName(QStringLiteral("pushButton_46"));
        sizePolicy6.setHeightForWidth(pushButton_46->sizePolicy().hasHeightForWidth());
        pushButton_46->setSizePolicy(sizePolicy6);
        pushButton_46->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_46);

        pushButton_47 = new QPushButton(tab_9);
        pushButton_47->setObjectName(QStringLiteral("pushButton_47"));
        sizePolicy6.setHeightForWidth(pushButton_47->sizePolicy().hasHeightForWidth());
        pushButton_47->setSizePolicy(sizePolicy6);
        pushButton_47->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_47);

        pushButton_48 = new QPushButton(tab_9);
        pushButton_48->setObjectName(QStringLiteral("pushButton_48"));
        sizePolicy6.setHeightForWidth(pushButton_48->sizePolicy().hasHeightForWidth());
        pushButton_48->setSizePolicy(sizePolicy6);
        pushButton_48->setMinimumSize(QSize(100, 80));

        horizontalLayout_42->addWidget(pushButton_48);

        horizontalSpacer_32 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_42->addItem(horizontalSpacer_32);


        verticalLayout_6->addLayout(horizontalLayout_42);

        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setSpacing(60);
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        horizontalLayout_44->setContentsMargins(0, -1, 40, -1);
        pushButton_71 = new QPushButton(tab_9);
        pushButton_71->setObjectName(QStringLiteral("pushButton_71"));
        sizePolicy6.setHeightForWidth(pushButton_71->sizePolicy().hasHeightForWidth());
        pushButton_71->setSizePolicy(sizePolicy6);
        pushButton_71->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_71);

        pushButton_72 = new QPushButton(tab_9);
        pushButton_72->setObjectName(QStringLiteral("pushButton_72"));
        sizePolicy6.setHeightForWidth(pushButton_72->sizePolicy().hasHeightForWidth());
        pushButton_72->setSizePolicy(sizePolicy6);
        pushButton_72->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_72);

        pushButton_73 = new QPushButton(tab_9);
        pushButton_73->setObjectName(QStringLiteral("pushButton_73"));
        sizePolicy6.setHeightForWidth(pushButton_73->sizePolicy().hasHeightForWidth());
        pushButton_73->setSizePolicy(sizePolicy6);
        pushButton_73->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_73);

        pushButton_74 = new QPushButton(tab_9);
        pushButton_74->setObjectName(QStringLiteral("pushButton_74"));
        sizePolicy6.setHeightForWidth(pushButton_74->sizePolicy().hasHeightForWidth());
        pushButton_74->setSizePolicy(sizePolicy6);
        pushButton_74->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_74);

        pushButton_75 = new QPushButton(tab_9);
        pushButton_75->setObjectName(QStringLiteral("pushButton_75"));
        sizePolicy6.setHeightForWidth(pushButton_75->sizePolicy().hasHeightForWidth());
        pushButton_75->setSizePolicy(sizePolicy6);
        pushButton_75->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_75);

        pushButton_76 = new QPushButton(tab_9);
        pushButton_76->setObjectName(QStringLiteral("pushButton_76"));
        sizePolicy6.setHeightForWidth(pushButton_76->sizePolicy().hasHeightForWidth());
        pushButton_76->setSizePolicy(sizePolicy6);
        pushButton_76->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_76);

        pushButton_77 = new QPushButton(tab_9);
        pushButton_77->setObjectName(QStringLiteral("pushButton_77"));
        sizePolicy6.setHeightForWidth(pushButton_77->sizePolicy().hasHeightForWidth());
        pushButton_77->setSizePolicy(sizePolicy6);
        pushButton_77->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_77);

        pushButton_78 = new QPushButton(tab_9);
        pushButton_78->setObjectName(QStringLiteral("pushButton_78"));
        sizePolicy6.setHeightForWidth(pushButton_78->sizePolicy().hasHeightForWidth());
        pushButton_78->setSizePolicy(sizePolicy6);
        pushButton_78->setMinimumSize(QSize(100, 80));

        horizontalLayout_44->addWidget(pushButton_78);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_44->addItem(horizontalSpacer_33);


        verticalLayout_6->addLayout(horizontalLayout_44);


        gridLayout_9->addLayout(verticalLayout_6, 3, 0, 1, 1);

        label_17 = new QLabel(tab_9);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setFont(font4);

        gridLayout_9->addWidget(label_17, 0, 0, 1, 1);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(10);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        label_15 = new QLabel(tab_9);
        label_15->setObjectName(QStringLiteral("label_15"));
        QSizePolicy sizePolicy7(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(label_15->sizePolicy().hasHeightForWidth());
        label_15->setSizePolicy(sizePolicy7);
        label_15->setFont(font5);

        verticalLayout_5->addWidget(label_15);

        horizontalLayout_46 = new QHBoxLayout();
        horizontalLayout_46->setSpacing(60);
        horizontalLayout_46->setObjectName(QStringLiteral("horizontalLayout_46"));
        horizontalLayout_46->setContentsMargins(0, -1, 40, -1);
        pushButton41 = new QPushButton(tab_9);
        pushButton41->setObjectName(QStringLiteral("pushButton41"));
        sizePolicy6.setHeightForWidth(pushButton41->sizePolicy().hasHeightForWidth());
        pushButton41->setSizePolicy(sizePolicy6);
        pushButton41->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton41);

        pushButton42 = new QPushButton(tab_9);
        pushButton42->setObjectName(QStringLiteral("pushButton42"));
        sizePolicy6.setHeightForWidth(pushButton42->sizePolicy().hasHeightForWidth());
        pushButton42->setSizePolicy(sizePolicy6);
        pushButton42->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton42);

        pushButton43 = new QPushButton(tab_9);
        pushButton43->setObjectName(QStringLiteral("pushButton43"));
        sizePolicy6.setHeightForWidth(pushButton43->sizePolicy().hasHeightForWidth());
        pushButton43->setSizePolicy(sizePolicy6);
        pushButton43->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton43);

        pushButton44 = new QPushButton(tab_9);
        pushButton44->setObjectName(QStringLiteral("pushButton44"));
        sizePolicy6.setHeightForWidth(pushButton44->sizePolicy().hasHeightForWidth());
        pushButton44->setSizePolicy(sizePolicy6);
        pushButton44->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton44);

        pushButton45 = new QPushButton(tab_9);
        pushButton45->setObjectName(QStringLiteral("pushButton45"));
        sizePolicy6.setHeightForWidth(pushButton45->sizePolicy().hasHeightForWidth());
        pushButton45->setSizePolicy(sizePolicy6);
        pushButton45->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton45);

        pushButton46 = new QPushButton(tab_9);
        pushButton46->setObjectName(QStringLiteral("pushButton46"));
        sizePolicy6.setHeightForWidth(pushButton46->sizePolicy().hasHeightForWidth());
        pushButton46->setSizePolicy(sizePolicy6);
        pushButton46->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton46);

        pushButton47 = new QPushButton(tab_9);
        pushButton47->setObjectName(QStringLiteral("pushButton47"));
        sizePolicy6.setHeightForWidth(pushButton47->sizePolicy().hasHeightForWidth());
        pushButton47->setSizePolicy(sizePolicy6);
        pushButton47->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton47);

        pushButton48 = new QPushButton(tab_9);
        pushButton48->setObjectName(QStringLiteral("pushButton48"));
        sizePolicy6.setHeightForWidth(pushButton48->sizePolicy().hasHeightForWidth());
        pushButton48->setSizePolicy(sizePolicy6);
        pushButton48->setMinimumSize(QSize(100, 80));

        horizontalLayout_46->addWidget(pushButton48);

        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_46->addItem(horizontalSpacer_28);


        verticalLayout_5->addLayout(horizontalLayout_46);

        horizontalLayout_45 = new QHBoxLayout();
        horizontalLayout_45->setSpacing(60);
        horizontalLayout_45->setObjectName(QStringLiteral("horizontalLayout_45"));
        horizontalLayout_45->setContentsMargins(0, -1, 40, -1);
        pushButton_79 = new QPushButton(tab_9);
        pushButton_79->setObjectName(QStringLiteral("pushButton_79"));
        sizePolicy6.setHeightForWidth(pushButton_79->sizePolicy().hasHeightForWidth());
        pushButton_79->setSizePolicy(sizePolicy6);
        pushButton_79->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_79);

        pushButton_80 = new QPushButton(tab_9);
        pushButton_80->setObjectName(QStringLiteral("pushButton_80"));
        sizePolicy6.setHeightForWidth(pushButton_80->sizePolicy().hasHeightForWidth());
        pushButton_80->setSizePolicy(sizePolicy6);
        pushButton_80->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_80);

        pushButton_81 = new QPushButton(tab_9);
        pushButton_81->setObjectName(QStringLiteral("pushButton_81"));
        sizePolicy6.setHeightForWidth(pushButton_81->sizePolicy().hasHeightForWidth());
        pushButton_81->setSizePolicy(sizePolicy6);
        pushButton_81->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_81);

        pushButton_82 = new QPushButton(tab_9);
        pushButton_82->setObjectName(QStringLiteral("pushButton_82"));
        sizePolicy6.setHeightForWidth(pushButton_82->sizePolicy().hasHeightForWidth());
        pushButton_82->setSizePolicy(sizePolicy6);
        pushButton_82->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_82);

        pushButton_83 = new QPushButton(tab_9);
        pushButton_83->setObjectName(QStringLiteral("pushButton_83"));
        sizePolicy6.setHeightForWidth(pushButton_83->sizePolicy().hasHeightForWidth());
        pushButton_83->setSizePolicy(sizePolicy6);
        pushButton_83->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_83);

        pushButton_84 = new QPushButton(tab_9);
        pushButton_84->setObjectName(QStringLiteral("pushButton_84"));
        sizePolicy6.setHeightForWidth(pushButton_84->sizePolicy().hasHeightForWidth());
        pushButton_84->setSizePolicy(sizePolicy6);
        pushButton_84->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_84);

        pushButton_85 = new QPushButton(tab_9);
        pushButton_85->setObjectName(QStringLiteral("pushButton_85"));
        sizePolicy6.setHeightForWidth(pushButton_85->sizePolicy().hasHeightForWidth());
        pushButton_85->setSizePolicy(sizePolicy6);
        pushButton_85->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_85);

        pushButton_86 = new QPushButton(tab_9);
        pushButton_86->setObjectName(QStringLiteral("pushButton_86"));
        sizePolicy6.setHeightForWidth(pushButton_86->sizePolicy().hasHeightForWidth());
        pushButton_86->setSizePolicy(sizePolicy6);
        pushButton_86->setMinimumSize(QSize(100, 80));

        horizontalLayout_45->addWidget(pushButton_86);

        horizontalSpacer_29 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_45->addItem(horizontalSpacer_29);


        verticalLayout_5->addLayout(horizontalLayout_45);

        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setSpacing(60);
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        horizontalLayout_43->setContentsMargins(0, -1, 40, -1);
        pushButton49 = new QPushButton(tab_9);
        pushButton49->setObjectName(QStringLiteral("pushButton49"));
        sizePolicy6.setHeightForWidth(pushButton49->sizePolicy().hasHeightForWidth());
        pushButton49->setSizePolicy(sizePolicy6);
        pushButton49->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton49);

        pushButton50 = new QPushButton(tab_9);
        pushButton50->setObjectName(QStringLiteral("pushButton50"));
        sizePolicy6.setHeightForWidth(pushButton50->sizePolicy().hasHeightForWidth());
        pushButton50->setSizePolicy(sizePolicy6);
        pushButton50->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton50);

        pushButton51 = new QPushButton(tab_9);
        pushButton51->setObjectName(QStringLiteral("pushButton51"));
        sizePolicy6.setHeightForWidth(pushButton51->sizePolicy().hasHeightForWidth());
        pushButton51->setSizePolicy(sizePolicy6);
        pushButton51->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton51);

        pushButton52 = new QPushButton(tab_9);
        pushButton52->setObjectName(QStringLiteral("pushButton52"));
        sizePolicy6.setHeightForWidth(pushButton52->sizePolicy().hasHeightForWidth());
        pushButton52->setSizePolicy(sizePolicy6);
        pushButton52->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton52);

        pushButton53 = new QPushButton(tab_9);
        pushButton53->setObjectName(QStringLiteral("pushButton53"));
        sizePolicy6.setHeightForWidth(pushButton53->sizePolicy().hasHeightForWidth());
        pushButton53->setSizePolicy(sizePolicy6);
        pushButton53->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton53);

        pushButton54 = new QPushButton(tab_9);
        pushButton54->setObjectName(QStringLiteral("pushButton54"));
        sizePolicy6.setHeightForWidth(pushButton54->sizePolicy().hasHeightForWidth());
        pushButton54->setSizePolicy(sizePolicy6);
        pushButton54->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton54);

        pushButton55 = new QPushButton(tab_9);
        pushButton55->setObjectName(QStringLiteral("pushButton55"));
        sizePolicy6.setHeightForWidth(pushButton55->sizePolicy().hasHeightForWidth());
        pushButton55->setSizePolicy(sizePolicy6);
        pushButton55->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton55);

        pushButton56 = new QPushButton(tab_9);
        pushButton56->setObjectName(QStringLiteral("pushButton56"));
        sizePolicy6.setHeightForWidth(pushButton56->sizePolicy().hasHeightForWidth());
        pushButton56->setSizePolicy(sizePolicy6);
        pushButton56->setMinimumSize(QSize(100, 80));

        horizontalLayout_43->addWidget(pushButton56);

        horizontalSpacer_30 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_43->addItem(horizontalSpacer_30);


        verticalLayout_5->addLayout(horizontalLayout_43);


        gridLayout_9->addLayout(verticalLayout_5, 1, 0, 1, 1);


        gridLayout_11->addLayout(gridLayout_9, 1, 1, 1, 1);

        verticalSpacer_14 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_11->addItem(verticalSpacer_14, 0, 1, 1, 1);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_11->addItem(horizontalSpacer_15, 1, 0, 1, 1);

        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_11->addItem(horizontalSpacer_20, 1, 2, 1, 1);

        verticalSpacer_13 = new QSpacerItem(20, 15, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout_11->addItem(verticalSpacer_13, 3, 1, 1, 1);

        testWidget->addTab(tab_9, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        horizontalLayout_20 = new QHBoxLayout(tab_3);
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        horizontalLayout_20->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(tab_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        QSizePolicy sizePolicy8(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy8.setHorizontalStretch(0);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy8);
        label_4->setMinimumSize(QSize(0, 0));
        label_4->setFrameShape(QFrame::NoFrame);
        label_4->setFrameShadow(QFrame::Raised);
        label_4->setTextFormat(Qt::RichText);
        label_4->setScaledContents(true);
        label_4->setAlignment(Qt::AlignCenter);

        horizontalLayout_20->addWidget(label_4);

        testWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        tab_4->setStyleSheet(QLatin1String("QTextEdit {\n"
"	color: rgb(234, 234, 234); \n"
"	background-color: rgb(25, 105, 154); \n"
"	font: bold;\n"
"	font-size : 24px;\n"
"}"));
        gridLayout_3 = new QGridLayout(tab_4);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setVerticalSpacing(10);
        gridLayout_3->setContentsMargins(60, 20, 60, 80);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(40);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        net_textEdit1 = new QTextEdit(tab_4);
        net_textEdit1->setObjectName(QStringLiteral("net_textEdit1"));
        sizePolicy3.setHeightForWidth(net_textEdit1->sizePolicy().hasHeightForWidth());
        net_textEdit1->setSizePolicy(sizePolicy3);
        net_textEdit1->setMinimumSize(QSize(0, 40));
        net_textEdit1->setMaximumSize(QSize(16777215, 40));
        net_textEdit1->setFrameShadow(QFrame::Raised);
        net_textEdit1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit1->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit1->setUndoRedoEnabled(false);
        net_textEdit1->setReadOnly(true);

        verticalLayout_4->addWidget(net_textEdit1);

        net_textEdit2 = new QTextEdit(tab_4);
        net_textEdit2->setObjectName(QStringLiteral("net_textEdit2"));
        sizePolicy3.setHeightForWidth(net_textEdit2->sizePolicy().hasHeightForWidth());
        net_textEdit2->setSizePolicy(sizePolicy3);
        net_textEdit2->setMinimumSize(QSize(0, 40));
        net_textEdit2->setMaximumSize(QSize(16777215, 40));
        net_textEdit2->setFrameShadow(QFrame::Raised);
        net_textEdit2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2->setUndoRedoEnabled(false);
        net_textEdit2->setReadOnly(true);

        verticalLayout_4->addWidget(net_textEdit2);

        net_textEdit2_2 = new QTextEdit(tab_4);
        net_textEdit2_2->setObjectName(QStringLiteral("net_textEdit2_2"));
        sizePolicy3.setHeightForWidth(net_textEdit2_2->sizePolicy().hasHeightForWidth());
        net_textEdit2_2->setSizePolicy(sizePolicy3);
        net_textEdit2_2->setMinimumSize(QSize(0, 40));
        net_textEdit2_2->setMaximumSize(QSize(16777215, 40));
        net_textEdit2_2->setFrameShadow(QFrame::Raised);
        net_textEdit2_2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_2->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_2->setUndoRedoEnabled(false);
        net_textEdit2_2->setReadOnly(true);

        verticalLayout_4->addWidget(net_textEdit2_2);

        net_textEdit2_3 = new QTextEdit(tab_4);
        net_textEdit2_3->setObjectName(QStringLiteral("net_textEdit2_3"));
        sizePolicy3.setHeightForWidth(net_textEdit2_3->sizePolicy().hasHeightForWidth());
        net_textEdit2_3->setSizePolicy(sizePolicy3);
        net_textEdit2_3->setMinimumSize(QSize(0, 40));
        net_textEdit2_3->setMaximumSize(QSize(16777215, 40));
        net_textEdit2_3->setFrameShadow(QFrame::Raised);
        net_textEdit2_3->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_3->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_3->setUndoRedoEnabled(false);
        net_textEdit2_3->setReadOnly(true);

        verticalLayout_4->addWidget(net_textEdit2_3);

        net_textEdit2_4 = new QTextEdit(tab_4);
        net_textEdit2_4->setObjectName(QStringLiteral("net_textEdit2_4"));
        sizePolicy3.setHeightForWidth(net_textEdit2_4->sizePolicy().hasHeightForWidth());
        net_textEdit2_4->setSizePolicy(sizePolicy3);
        net_textEdit2_4->setMinimumSize(QSize(0, 40));
        net_textEdit2_4->setMaximumSize(QSize(16777215, 40));
        net_textEdit2_4->setFrameShadow(QFrame::Raised);
        net_textEdit2_4->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_4->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_4->setUndoRedoEnabled(false);
        net_textEdit2_4->setReadOnly(true);

        verticalLayout_4->addWidget(net_textEdit2_4);

        net_textEdit2_5 = new QTextEdit(tab_4);
        net_textEdit2_5->setObjectName(QStringLiteral("net_textEdit2_5"));
        sizePolicy3.setHeightForWidth(net_textEdit2_5->sizePolicy().hasHeightForWidth());
        net_textEdit2_5->setSizePolicy(sizePolicy3);
        net_textEdit2_5->setMinimumSize(QSize(0, 40));
        net_textEdit2_5->setMaximumSize(QSize(16777215, 40));
        net_textEdit2_5->setFrameShadow(QFrame::Raised);
        net_textEdit2_5->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_5->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        net_textEdit2_5->setUndoRedoEnabled(false);
        net_textEdit2_5->setReadOnly(true);

        verticalLayout_4->addWidget(net_textEdit2_5);


        gridLayout_3->addLayout(verticalLayout_4, 2, 0, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_12 = new QLabel(tab_4);
        label_12->setObjectName(QStringLiteral("label_12"));
        sizePolicy7.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy7);
        QFont font6;
        font6.setFamily(QString::fromUtf8("\346\226\271\346\255\243\346\245\267\344\275\223"));
        label_12->setFont(font6);

        verticalLayout_2->addWidget(label_12);

        frame_2 = new QFrame(tab_4);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        QSizePolicy sizePolicy9(QSizePolicy::MinimumExpanding, QSizePolicy::Fixed);
        sizePolicy9.setHorizontalStretch(0);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(frame_2->sizePolicy().hasHeightForWidth());
        frame_2->setSizePolicy(sizePolicy9);
        frame_2->setFrameShape(QFrame::NoFrame);
        frame_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_21 = new QHBoxLayout(frame_2);
        horizontalLayout_21->setSpacing(0);
        horizontalLayout_21->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        horizontalLayout_21->setContentsMargins(0, 0, 0, 0);

        verticalLayout_2->addWidget(frame_2);


        gridLayout_3->addLayout(verticalLayout_2, 1, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 80, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_2, 3, 0, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_3->addItem(verticalSpacer_3, 0, 0, 1, 1);

        testWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        tab_5->setStyleSheet(QLatin1String("QTextEdit {\n"
"	color: rgb(234, 234, 234); \n"
"	background-color: rgb(25, 105, 154); \n"
"	font: bold;\n"
"	font-size : 23px;\n"
"}"));
        gridLayout_8 = new QGridLayout(tab_5);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        gridLayout_8->setHorizontalSpacing(0);
        gridLayout_8->setVerticalSpacing(12);
        gridLayout_8->setContentsMargins(60, 0, 60, 0);
        verticalSpacer_11 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_8->addItem(verticalSpacer_11, 0, 0, 1, 1);

        label_28 = new QLabel(tab_5);
        label_28->setObjectName(QStringLiteral("label_28"));
        sizePolicy7.setHeightForWidth(label_28->sizePolicy().hasHeightForWidth());
        label_28->setSizePolicy(sizePolicy7);
        label_28->setFont(font6);

        gridLayout_8->addWidget(label_28, 1, 0, 1, 1);

        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setSpacing(30);
        verticalLayout_24->setObjectName(QStringLiteral("verticalLayout_24"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(4);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        label_18 = new QLabel(tab_5);
        label_18->setObjectName(QStringLiteral("label_18"));
        sizePolicy7.setHeightForWidth(label_18->sizePolicy().hasHeightForWidth());
        label_18->setSizePolicy(sizePolicy7);
        QFont font7;
        font7.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        font7.setPointSize(14);
        label_18->setFont(font7);

        verticalLayout_7->addWidget(label_18);

        textEdit_1 = new QTextEdit(tab_5);
        textEdit_1->setObjectName(QStringLiteral("textEdit_1"));
        QSizePolicy sizePolicy10(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy10.setHorizontalStretch(0);
        sizePolicy10.setVerticalStretch(10);
        sizePolicy10.setHeightForWidth(textEdit_1->sizePolicy().hasHeightForWidth());
        textEdit_1->setSizePolicy(sizePolicy10);
        textEdit_1->setMinimumSize(QSize(0, 30));
        textEdit_1->setMaximumSize(QSize(16777215, 40));
        QFont font8;
        font8.setBold(true);
        font8.setItalic(false);
        font8.setWeight(75);
        textEdit_1->setFont(font8);
        textEdit_1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_1->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_1->setUndoRedoEnabled(false);
        textEdit_1->setReadOnly(true);

        verticalLayout_7->addWidget(textEdit_1);


        verticalLayout_10->addLayout(verticalLayout_7);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        label_19 = new QLabel(tab_5);
        label_19->setObjectName(QStringLiteral("label_19"));
        sizePolicy7.setHeightForWidth(label_19->sizePolicy().hasHeightForWidth());
        label_19->setSizePolicy(sizePolicy7);
        label_19->setFont(font7);

        verticalLayout_8->addWidget(label_19);

        textEdit_10 = new QTextEdit(tab_5);
        textEdit_10->setObjectName(QStringLiteral("textEdit_10"));
        sizePolicy10.setHeightForWidth(textEdit_10->sizePolicy().hasHeightForWidth());
        textEdit_10->setSizePolicy(sizePolicy10);
        textEdit_10->setMinimumSize(QSize(0, 30));
        textEdit_10->setMaximumSize(QSize(16777215, 40));
        textEdit_10->setFont(font8);
        textEdit_10->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_10->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_10->setUndoRedoEnabled(false);
        textEdit_10->setReadOnly(true);

        verticalLayout_8->addWidget(textEdit_10);


        verticalLayout_10->addLayout(verticalLayout_8);


        verticalLayout_24->addLayout(verticalLayout_10);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(4);
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(0);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        label_20 = new QLabel(tab_5);
        label_20->setObjectName(QStringLiteral("label_20"));
        sizePolicy7.setHeightForWidth(label_20->sizePolicy().hasHeightForWidth());
        label_20->setSizePolicy(sizePolicy7);
        label_20->setFont(font7);

        verticalLayout_11->addWidget(label_20);

        textEdit_2 = new QTextEdit(tab_5);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        sizePolicy10.setHeightForWidth(textEdit_2->sizePolicy().hasHeightForWidth());
        textEdit_2->setSizePolicy(sizePolicy10);
        textEdit_2->setMinimumSize(QSize(0, 30));
        textEdit_2->setMaximumSize(QSize(16777215, 40));
        textEdit_2->setFont(font8);
        textEdit_2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_2->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_2->setUndoRedoEnabled(false);
        textEdit_2->setReadOnly(true);

        verticalLayout_11->addWidget(textEdit_2);


        verticalLayout_14->addLayout(verticalLayout_11);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(0);
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        label_21 = new QLabel(tab_5);
        label_21->setObjectName(QStringLiteral("label_21"));
        sizePolicy7.setHeightForWidth(label_21->sizePolicy().hasHeightForWidth());
        label_21->setSizePolicy(sizePolicy7);
        label_21->setFont(font7);

        verticalLayout_13->addWidget(label_21);

        textEdit_8 = new QTextEdit(tab_5);
        textEdit_8->setObjectName(QStringLiteral("textEdit_8"));
        sizePolicy10.setHeightForWidth(textEdit_8->sizePolicy().hasHeightForWidth());
        textEdit_8->setSizePolicy(sizePolicy10);
        textEdit_8->setMinimumSize(QSize(0, 30));
        textEdit_8->setMaximumSize(QSize(16777215, 40));
        textEdit_8->setFont(font8);
        textEdit_8->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_8->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_8->setUndoRedoEnabled(false);
        textEdit_8->setReadOnly(true);

        verticalLayout_13->addWidget(textEdit_8);


        verticalLayout_14->addLayout(verticalLayout_13);


        verticalLayout_24->addLayout(verticalLayout_14);

        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setSpacing(4);
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setSpacing(0);
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        label_23 = new QLabel(tab_5);
        label_23->setObjectName(QStringLiteral("label_23"));
        sizePolicy7.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy7);
        label_23->setFont(font7);

        verticalLayout_15->addWidget(label_23);

        textEdit_3 = new QTextEdit(tab_5);
        textEdit_3->setObjectName(QStringLiteral("textEdit_3"));
        sizePolicy10.setHeightForWidth(textEdit_3->sizePolicy().hasHeightForWidth());
        textEdit_3->setSizePolicy(sizePolicy10);
        textEdit_3->setMinimumSize(QSize(0, 30));
        textEdit_3->setMaximumSize(QSize(16777215, 40));
        textEdit_3->setFont(font8);
        textEdit_3->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_3->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_3->setUndoRedoEnabled(false);
        textEdit_3->setReadOnly(true);

        verticalLayout_15->addWidget(textEdit_3);


        verticalLayout_17->addLayout(verticalLayout_15);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setSpacing(0);
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        label_22 = new QLabel(tab_5);
        label_22->setObjectName(QStringLiteral("label_22"));
        sizePolicy7.setHeightForWidth(label_22->sizePolicy().hasHeightForWidth());
        label_22->setSizePolicy(sizePolicy7);
        label_22->setFont(font7);

        verticalLayout_16->addWidget(label_22);

        textEdit_9 = new QTextEdit(tab_5);
        textEdit_9->setObjectName(QStringLiteral("textEdit_9"));
        sizePolicy10.setHeightForWidth(textEdit_9->sizePolicy().hasHeightForWidth());
        textEdit_9->setSizePolicy(sizePolicy10);
        textEdit_9->setMinimumSize(QSize(0, 30));
        textEdit_9->setMaximumSize(QSize(16777215, 40));
        textEdit_9->setFont(font8);
        textEdit_9->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_9->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_9->setUndoRedoEnabled(false);
        textEdit_9->setReadOnly(true);

        verticalLayout_16->addWidget(textEdit_9);


        verticalLayout_17->addLayout(verticalLayout_16);


        verticalLayout_24->addLayout(verticalLayout_17);


        gridLayout_8->addLayout(verticalLayout_24, 3, 0, 1, 1);

        verticalSpacer_12 = new QSpacerItem(20, 80, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout_8->addItem(verticalSpacer_12, 4, 0, 1, 1);

        uart_label = new QLabel(tab_5);
        uart_label->setObjectName(QStringLiteral("uart_label"));
        QFont font9;
        font9.setFamily(QString::fromUtf8("\346\226\271\346\255\243\346\245\267\344\275\223"));
        font9.setPointSize(16);
        uart_label->setFont(font9);
        uart_label->setStyleSheet(QLatin1String("border: none;\n"
"color: rgb(234, 234, 234)"));

        gridLayout_8->addWidget(uart_label, 2, 0, 1, 1);

        testWidget->addTab(tab_5, QString());
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        tab_7->setStyleSheet(QStringLiteral(""));
        gridLayout_10 = new QGridLayout(tab_7);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        gridLayout_10->setVerticalSpacing(0);
        gridLayout_10->setContentsMargins(80, 0, 100, 0);
        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        frame = new QFrame(tab_7);
        frame->setObjectName(QStringLiteral("frame"));
        sizePolicy7.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy7);
        frame->setMinimumSize(QSize(800, 550));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        groupBox_3 = new QGroupBox(frame);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(30, 90, 301, 431));
        groupBox_3->setStyleSheet(QLatin1String("QGroupBox {\n"
"	color: rgb(234, 234, 234);\n"
"	border: 1px solid #b8b8b9;\n"
"}\n"
"\n"
"QPushButton {\n"
"	color: rgb(0, 0, 0);\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                        stop: 0 #f6f7fa, stop: 1 #dadbde);\n"
"    border-width: 2px;\n"
"    border-color: rgb(187, 188, 190);\n"
"    border-style: inset;\n"
"\n"
"    padding: 3px;\n"
"    border: 1px solid #b8b8b9;\n"
"    border-radius: 6px;\n"
"}\n"
"\n"
"QPushButton:flat {\n"
"    border: none; /* no border for a flat push button */\n"
"}\n"
"\n"
"QPushButton:default {\n"
"    border-color: navy; /* make the default button prominent */\n"
"}"));
        k5PushButton = new QPushButton(groupBox_3);
        k5PushButton->setObjectName(QStringLiteral("k5PushButton"));
        k5PushButton->setGeometry(QRect(30, 230, 61, 41));
        k6PushButton = new QPushButton(groupBox_3);
        k6PushButton->setObjectName(QStringLiteral("k6PushButton"));
        k6PushButton->setGeometry(QRect(90, 230, 61, 41));
        k7PushButton = new QPushButton(groupBox_3);
        k7PushButton->setObjectName(QStringLiteral("k7PushButton"));
        k7PushButton->setGeometry(QRect(150, 230, 61, 41));
        k8PushButton = new QPushButton(groupBox_3);
        k8PushButton->setObjectName(QStringLiteral("k8PushButton"));
        k8PushButton->setGeometry(QRect(210, 230, 61, 41));
        k9PushButton = new QPushButton(groupBox_3);
        k9PushButton->setObjectName(QStringLiteral("k9PushButton"));
        k9PushButton->setGeometry(QRect(30, 140, 61, 41));
        k10PushButton = new QPushButton(groupBox_3);
        k10PushButton->setObjectName(QStringLiteral("k10PushButton"));
        k10PushButton->setGeometry(QRect(90, 140, 61, 41));
        k11PushButton = new QPushButton(groupBox_3);
        k11PushButton->setObjectName(QStringLiteral("k11PushButton"));
        k11PushButton->setGeometry(QRect(150, 140, 61, 41));
        k12PushButton = new QPushButton(groupBox_3);
        k12PushButton->setObjectName(QStringLiteral("k12PushButton"));
        k12PushButton->setGeometry(QRect(210, 140, 61, 41));
        k12PushButton->setStyleSheet(QStringLiteral(""));
        k13PushButton = new QPushButton(groupBox_3);
        k13PushButton->setObjectName(QStringLiteral("k13PushButton"));
        k13PushButton->setGeometry(QRect(30, 50, 61, 41));
        k14PushButton = new QPushButton(groupBox_3);
        k14PushButton->setObjectName(QStringLiteral("k14PushButton"));
        k14PushButton->setGeometry(QRect(90, 50, 61, 41));
        k15PushButton = new QPushButton(groupBox_3);
        k15PushButton->setObjectName(QStringLiteral("k15PushButton"));
        k15PushButton->setGeometry(QRect(150, 50, 61, 41));
        k16PushButton = new QPushButton(groupBox_3);
        k16PushButton->setObjectName(QStringLiteral("k16PushButton"));
        k16PushButton->setGeometry(QRect(210, 50, 61, 41));
        k9LineEdit = new QLineEdit(groupBox_3);
        k9LineEdit->setObjectName(QStringLiteral("k9LineEdit"));
        k9LineEdit->setGeometry(QRect(30, 180, 61, 41));
        k9LineEdit->setAlignment(Qt::AlignCenter);
        k9LineEdit->setReadOnly(true);
        k10LineEdit = new QLineEdit(groupBox_3);
        k10LineEdit->setObjectName(QStringLiteral("k10LineEdit"));
        k10LineEdit->setGeometry(QRect(90, 180, 61, 41));
        k10LineEdit->setAlignment(Qt::AlignCenter);
        k10LineEdit->setReadOnly(true);
        k11LineEdit = new QLineEdit(groupBox_3);
        k11LineEdit->setObjectName(QStringLiteral("k11LineEdit"));
        k11LineEdit->setGeometry(QRect(150, 180, 61, 41));
        k11LineEdit->setAlignment(Qt::AlignCenter);
        k11LineEdit->setReadOnly(true);
        k12LineEdit = new QLineEdit(groupBox_3);
        k12LineEdit->setObjectName(QStringLiteral("k12LineEdit"));
        k12LineEdit->setGeometry(QRect(210, 180, 61, 41));
        k12LineEdit->setAlignment(Qt::AlignCenter);
        k12LineEdit->setReadOnly(true);
        k13LineEdit = new QLineEdit(groupBox_3);
        k13LineEdit->setObjectName(QStringLiteral("k13LineEdit"));
        k13LineEdit->setGeometry(QRect(30, 90, 61, 41));
        k13LineEdit->setAlignment(Qt::AlignCenter);
        k13LineEdit->setReadOnly(true);
        k14LineEdit = new QLineEdit(groupBox_3);
        k14LineEdit->setObjectName(QStringLiteral("k14LineEdit"));
        k14LineEdit->setGeometry(QRect(90, 90, 61, 41));
        k14LineEdit->setAlignment(Qt::AlignCenter);
        k14LineEdit->setReadOnly(true);
        k15LineEdit = new QLineEdit(groupBox_3);
        k15LineEdit->setObjectName(QStringLiteral("k15LineEdit"));
        k15LineEdit->setGeometry(QRect(150, 90, 61, 41));
        k15LineEdit->setAlignment(Qt::AlignCenter);
        k15LineEdit->setReadOnly(true);
        k16LineEdit = new QLineEdit(groupBox_3);
        k16LineEdit->setObjectName(QStringLiteral("k16LineEdit"));
        k16LineEdit->setGeometry(QRect(210, 90, 61, 41));
        k16LineEdit->setAlignment(Qt::AlignCenter);
        k16LineEdit->setReadOnly(true);
        k1PushButton = new QPushButton(groupBox_3);
        k1PushButton->setObjectName(QStringLiteral("k1PushButton"));
        k1PushButton->setGeometry(QRect(30, 320, 61, 41));
        k4PushButton = new QPushButton(groupBox_3);
        k4PushButton->setObjectName(QStringLiteral("k4PushButton"));
        k4PushButton->setGeometry(QRect(210, 320, 61, 41));
        k2PushButton = new QPushButton(groupBox_3);
        k2PushButton->setObjectName(QStringLiteral("k2PushButton"));
        k2PushButton->setGeometry(QRect(90, 320, 61, 41));
        k3PushButton = new QPushButton(groupBox_3);
        k3PushButton->setObjectName(QStringLiteral("k3PushButton"));
        k3PushButton->setGeometry(QRect(150, 320, 61, 41));
        k1LineEdit = new QLineEdit(groupBox_3);
        k1LineEdit->setObjectName(QStringLiteral("k1LineEdit"));
        k1LineEdit->setGeometry(QRect(30, 360, 61, 41));
        k1LineEdit->setAlignment(Qt::AlignCenter);
        k1LineEdit->setReadOnly(true);
        k2LineEdit = new QLineEdit(groupBox_3);
        k2LineEdit->setObjectName(QStringLiteral("k2LineEdit"));
        k2LineEdit->setGeometry(QRect(90, 360, 61, 41));
        k2LineEdit->setAlignment(Qt::AlignCenter);
        k2LineEdit->setReadOnly(true);
        k3LineEdit = new QLineEdit(groupBox_3);
        k3LineEdit->setObjectName(QStringLiteral("k3LineEdit"));
        k3LineEdit->setGeometry(QRect(150, 360, 61, 41));
        k3LineEdit->setAlignment(Qt::AlignCenter);
        k3LineEdit->setReadOnly(true);
        k4LineEdit = new QLineEdit(groupBox_3);
        k4LineEdit->setObjectName(QStringLiteral("k4LineEdit"));
        k4LineEdit->setGeometry(QRect(210, 360, 61, 41));
        k4LineEdit->setAlignment(Qt::AlignCenter);
        k4LineEdit->setReadOnly(true);
        k5LineEdit = new QLineEdit(groupBox_3);
        k5LineEdit->setObjectName(QStringLiteral("k5LineEdit"));
        k5LineEdit->setGeometry(QRect(30, 270, 61, 41));
        k5LineEdit->setAlignment(Qt::AlignCenter);
        k5LineEdit->setReadOnly(true);
        k6LineEdit = new QLineEdit(groupBox_3);
        k6LineEdit->setObjectName(QStringLiteral("k6LineEdit"));
        k6LineEdit->setGeometry(QRect(90, 270, 61, 41));
        k6LineEdit->setAlignment(Qt::AlignCenter);
        k6LineEdit->setReadOnly(true);
        k7LineEdit = new QLineEdit(groupBox_3);
        k7LineEdit->setObjectName(QStringLiteral("k7LineEdit"));
        k7LineEdit->setGeometry(QRect(150, 270, 61, 41));
        k7LineEdit->setAlignment(Qt::AlignCenter);
        k7LineEdit->setReadOnly(true);
        k8LineEdit = new QLineEdit(groupBox_3);
        k8LineEdit->setObjectName(QStringLiteral("k8LineEdit"));
        k8LineEdit->setGeometry(QRect(210, 270, 61, 41));
        k8LineEdit->setAlignment(Qt::AlignCenter);
        k8LineEdit->setReadOnly(true);
        layoutWidget = new QWidget(frame);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 30, 301, 52));
        horizontalLayout_16 = new QHBoxLayout(layoutWidget);
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(0, 0, 0, 0);
        QueryCodePushButton = new QPushButton(layoutWidget);
        QueryCodePushButton->setObjectName(QStringLiteral("QueryCodePushButton"));
        QueryCodePushButton->setMinimumSize(QSize(0, 30));
        QueryCodePushButton->setFont(font4);
        QueryCodePushButton->setStyleSheet(QLatin1String("QPushButton {\n"
"	color: white;\n"
"    border-right: 1px solid rgb(180, 180, 180);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(23, 95, 139, 255),\n"
"        stop:1 rgba(27, 110, 162, 255));\n"
"    border-width: 2px;\n"
"    border-color: rgb(150, 150, 150);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}"));
        QueryCodePushButton->setCheckable(false);

        horizontalLayout_16->addWidget(QueryCodePushButton);

        clearrecPushButton = new QPushButton(layoutWidget);
        clearrecPushButton->setObjectName(QStringLiteral("clearrecPushButton"));
        clearrecPushButton->setMinimumSize(QSize(0, 30));
        clearrecPushButton->setFont(font4);
        clearrecPushButton->setStyleSheet(QLatin1String("QPushButton {\n"
"	color: white;\n"
"    border-right: 1px solid rgb(180, 180, 180);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(23, 95, 139, 255),\n"
"        stop:1 rgba(27, 110, 162, 255));\n"
"    border-width: 2px;\n"
"    border-color: rgb(150, 150, 150);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}"));

        horizontalLayout_16->addWidget(clearrecPushButton);

        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_22);

        groupBox_2 = new QGroupBox(frame);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(480, 270, 281, 251));
        groupBox_2->setStyleSheet(QLatin1String("QGroupBox {\n"
"	color: rgb(234, 234, 234);\n"
"	border: 1px solid #b8b8b9;\n"
"}"));
        keyTextEdit = new QTextEdit(groupBox_2);
        keyTextEdit->setObjectName(QStringLiteral("keyTextEdit"));
        keyTextEdit->setGeometry(QRect(30, 60, 221, 171));
        keyTextEdit->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        keyTextEdit->setUndoRedoEnabled(false);
        keyTextEdit->setReadOnly(true);
        layoutWidget1 = new QWidget(groupBox_2);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(30, 20, 221, 32));
        horizontalLayout_18 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(0, 0, 0, 0);
        queryclearPushButton = new QPushButton(layoutWidget1);
        queryclearPushButton->setObjectName(QStringLiteral("queryclearPushButton"));
        queryclearPushButton->setMinimumSize(QSize(50, 0));
        queryclearPushButton->setFont(font4);
        queryclearPushButton->setStyleSheet(QLatin1String("QPushButton {\n"
"	color: white;\n"
"    border-right: 1px solid rgb(180, 180, 180);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(23, 95, 139, 255),\n"
"        stop:1 rgba(27, 110, 162, 255));\n"
"    border-width: 2px;\n"
"    border-color: rgb(150, 150, 150);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}"));

        horizontalLayout_18->addWidget(queryclearPushButton);

        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_24);

        layoutWidget2 = new QWidget(frame);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(480, 31, 281, 51));
        horizontalLayout_17 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(0, 0, 0, 0);
        getPushButton = new QPushButton(layoutWidget2);
        getPushButton->setObjectName(QStringLiteral("getPushButton"));
        getPushButton->setMinimumSize(QSize(0, 30));
        getPushButton->setFont(font4);
        getPushButton->setStyleSheet(QLatin1String("QPushButton {\n"
"	color: white;\n"
"    border-right: 1px solid rgb(180, 180, 180);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(23, 95, 139, 255),\n"
"        stop:1 rgba(27, 110, 162, 255));\n"
"    border-width: 2px;\n"
"    border-color: rgb(150, 150, 150);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}"));

        horizontalLayout_17->addWidget(getPushButton);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_23);

        groupBox_4 = new QGroupBox(frame);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(480, 90, 281, 151));
        groupBox_4->setStyleSheet(QLatin1String("QGroupBox {\n"
"	color: rgb(234, 234, 234);\n"
"	border: 1px solid #b8b8b9;\n"
"}"));
        layoutWidget_2 = new QWidget(groupBox_4);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(41, 100, 191, 24));
        horizontalLayout_14 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget_2);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setStyleSheet(QStringLiteral("border-color: none"));
        label_9->setLineWidth(0);

        horizontalLayout_14->addWidget(label_9);

        pidLineEdit = new QLineEdit(layoutWidget_2);
        pidLineEdit->setObjectName(QStringLiteral("pidLineEdit"));
        sizePolicy3.setHeightForWidth(pidLineEdit->sizePolicy().hasHeightForWidth());
        pidLineEdit->setSizePolicy(sizePolicy3);
        pidLineEdit->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        pidLineEdit->setReadOnly(true);

        horizontalLayout_14->addWidget(pidLineEdit);

        layoutWidget_3 = new QWidget(groupBox_4);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(40, 40, 191, 24));
        horizontalLayout_15 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        horizontalLayout_15->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(layoutWidget_3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setStyleSheet(QStringLiteral("border-color: none"));
        label_10->setFrameShadow(QFrame::Sunken);
        label_10->setLineWidth(0);

        horizontalLayout_15->addWidget(label_10);

        vidLineEdit = new QLineEdit(layoutWidget_3);
        vidLineEdit->setObjectName(QStringLiteral("vidLineEdit"));
        vidLineEdit->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        vidLineEdit->setReadOnly(true);

        horizontalLayout_15->addWidget(vidLineEdit);

        line = new QFrame(frame);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(480, 250, 281, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(frame);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setGeometry(QRect(400, 50, 20, 471));
        line_3->setFrameShadow(QFrame::Sunken);
        line_3->setFrameShape(QFrame::VLine);

        horizontalLayout_19->addWidget(frame);


        verticalLayout_12->addLayout(horizontalLayout_19);


        gridLayout_10->addLayout(verticalLayout_12, 1, 1, 1, 1);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_10->addItem(verticalSpacer_9, 0, 1, 1, 1);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        gridLayout_10->addItem(horizontalSpacer_13, 1, 2, 1, 1);

        verticalSpacer_10 = new QSpacerItem(20, 120, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_10->addItem(verticalSpacer_10, 2, 1, 1, 1);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        gridLayout_10->addItem(horizontalSpacer_14, 1, 0, 1, 1);

        testWidget->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        tab_8->setStyleSheet(QLatin1String("QPushButton {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                        stop: 0 #f6f7fa, stop: 1 #dadbde);\n"
"    border-width: 2px;\n"
"    border-color: rgb(187, 188, 190);\n"
"    border-style: outset;\n"
"\n"
"    padding: 3px;\n"
"    border: 2px solid #9c9c9d;\n"
"    border-radius: 6px;\n"
"}\n"
"/*\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"*/\n"
"QPushButton:flat {\n"
"    border: none; /* no border for a flat push button */\n"
"}\n"
"\n"
"QPushButton:default {\n"
"    border-color: navy; /* make the default button prominent */\n"
"}\n"
"\n"
"QPushButton[current=\"true\"] {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}\n"
"/***\n"
""
                        "QPushButton {\n"
"    background-color: rgb(221, 221, 221);\n"
"    border-width: 2px;\n"
"    border-color: rgb(194, 194, 194);\n"
"    border-style: outset;\n"
"    border-radius: 5;\n"
"    padding: 3px;\n"
"    min-width: 9ex;\n"
"    min-height: 2.5ex;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"   background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgb(255, 89, 97);\n"
"}\n"
"\n"
"\n"
"QPushButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb(240,240,240);\n"
"\n"
"    padding-left:12px;\n"
"    padding-right: 12px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QPushButton[current=\"true\"] {\n"
"    border-top: 1px solid rgb(90,90,90);\n"
"    border-"
                        "right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QPushButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}*/"));
        gridLayout_7 = new QGridLayout(tab_8);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        gridLayout_7->setVerticalSpacing(30);
        gridLayout_7->setContentsMargins(-1, -1, -1, 120);
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_16);

        label_5 = new QLabel(tab_8);
        label_5->setObjectName(QStringLiteral("label_5"));
        sizePolicy7.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy7);

        horizontalLayout_5->addWidget(label_5);

        mousePos = new QLineEdit(tab_8);
        mousePos->setObjectName(QStringLiteral("mousePos"));
        QSizePolicy sizePolicy11(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy11.setHorizontalStretch(0);
        sizePolicy11.setVerticalStretch(0);
        sizePolicy11.setHeightForWidth(mousePos->sizePolicy().hasHeightForWidth());
        mousePos->setSizePolicy(sizePolicy11);
        mousePos->setReadOnly(true);

        horizontalLayout_5->addWidget(mousePos);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_17);


        gridLayout_7->addLayout(horizontalLayout_5, 2, 0, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(40);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, -1, 0, -1);
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_11);

        leftButton = new QPushButton(tab_8);
        leftButton->setObjectName(QStringLiteral("leftButton"));
        QSizePolicy sizePolicy12(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy12.setHorizontalStretch(40);
        sizePolicy12.setVerticalStretch(40);
        sizePolicy12.setHeightForWidth(leftButton->sizePolicy().hasHeightForWidth());
        leftButton->setSizePolicy(sizePolicy12);
        leftButton->setMinimumSize(QSize(200, 180));
        leftButton->setFlat(false);

        horizontalLayout_4->addWidget(leftButton);

        midButton = new QPushButton(tab_8);
        midButton->setObjectName(QStringLiteral("midButton"));
        sizePolicy12.setHeightForWidth(midButton->sizePolicy().hasHeightForWidth());
        midButton->setSizePolicy(sizePolicy12);
        midButton->setMinimumSize(QSize(200, 180));

        horizontalLayout_4->addWidget(midButton);

        rightButton = new QPushButton(tab_8);
        rightButton->setObjectName(QStringLiteral("rightButton"));
        sizePolicy12.setHeightForWidth(rightButton->sizePolicy().hasHeightForWidth());
        rightButton->setSizePolicy(sizePolicy12);
        rightButton->setMinimumSize(QSize(200, 180));

        horizontalLayout_4->addWidget(rightButton);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_12);


        gridLayout_7->addLayout(horizontalLayout_4, 1, 0, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_7->addItem(verticalSpacer_6, 3, 0, 1, 1);

        verticalSpacer_7 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout_7->addItem(verticalSpacer_7, 0, 0, 1, 1);

        testWidget->addTab(tab_8, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName(QStringLiteral("tab_11"));
        gridLayout_13 = new QGridLayout(tab_11);
        gridLayout_13->setSpacing(6);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        gridLayout_13->setVerticalSpacing(10);
        gridLayout_13->setContentsMargins(20, 20, 20, 20);
        textEdit_4 = new QTextEdit(tab_11);
        textEdit_4->setObjectName(QStringLiteral("textEdit_4"));
        QSizePolicy sizePolicy13(QSizePolicy::Expanding, QSizePolicy::Minimum);
        sizePolicy13.setHorizontalStretch(0);
        sizePolicy13.setVerticalStretch(0);
        sizePolicy13.setHeightForWidth(textEdit_4->sizePolicy().hasHeightForWidth());
        textEdit_4->setSizePolicy(sizePolicy13);
        textEdit_4->setFrameShape(QFrame::Box);
        textEdit_4->setFrameShadow(QFrame::Plain);
        textEdit_4->setUndoRedoEnabled(false);
        textEdit_4->setReadOnly(true);

        gridLayout_13->addWidget(textEdit_4, 1, 0, 1, 1);

        label_2 = new QLabel(tab_11);
        label_2->setObjectName(QStringLiteral("label_2"));
        sizePolicy7.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy7);
        QFont font10;
        font10.setFamily(QString::fromUtf8("\346\226\271\346\255\243\346\245\267\344\275\223"));
        font10.setPointSize(18);
        label_2->setFont(font10);

        gridLayout_13->addWidget(label_2, 0, 0, 1, 1);

        testWidget->addTab(tab_11, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayout_4 = new QGridLayout(tab);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        verticalSpacer_18 = new QSpacerItem(20, 228, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_4->addItem(verticalSpacer_18, 0, 1, 1, 1);

        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        sizePolicy7.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy7);
        groupBox->setMinimumSize(QSize(875, 270));
        groupBox->setStyleSheet(QStringLiteral("border: none;"));
        groupBox->setFlat(true);
        groupBox->setCheckable(false);
        deletePushButton = new QPushButton(groupBox);
        deletePushButton->setObjectName(QStringLiteral("deletePushButton"));
        deletePushButton->setGeometry(QRect(580, 100, 41, 41));
        deletePushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        upPushButton = new QPushButton(groupBox);
        upPushButton->setObjectName(QStringLiteral("upPushButton"));
        upPushButton->setGeometry(QRect(612, 170, 41, 41));
        upPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        titlePushButton = new QPushButton(groupBox);
        titlePushButton->setObjectName(QStringLiteral("titlePushButton"));
        titlePushButton->setGeometry(QRect(10, 60, 41, 41));
        titlePushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        EscPushButton = new QPushButton(groupBox);
        EscPushButton->setObjectName(QStringLiteral("EscPushButton"));
        EscPushButton->setGeometry(QRect(10, 10, 41, 41));
        EscPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        EscPushButton->setFlat(false);
        twoRightPushButton = new QPushButton(groupBox);
        twoRightPushButton->setObjectName(QStringLiteral("twoRightPushButton"));
        twoRightPushButton->setGeometry(QRect(742, 170, 41, 41));
        twoRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        rightDivisionPushButton = new QPushButton(groupBox);
        rightDivisionPushButton->setObjectName(QStringLiteral("rightDivisionPushButton"));
        rightDivisionPushButton->setGeometry(QRect(740, 60, 41, 41));
        rightDivisionPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        zeroUpPushButton = new QPushButton(groupBox);
        zeroUpPushButton->setObjectName(QStringLiteral("zeroUpPushButton"));
        zeroUpPushButton->setGeometry(QRect(380, 60, 41, 41));
        zeroUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        sevenRightPushButton = new QPushButton(groupBox);
        sevenRightPushButton->setObjectName(QStringLiteral("sevenRightPushButton"));
        sevenRightPushButton->setGeometry(QRect(700, 100, 41, 41));
        sevenRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        threeUpPushButton = new QPushButton(groupBox);
        threeUpPushButton->setObjectName(QStringLiteral("threeUpPushButton"));
        threeUpPushButton->setGeometry(QRect(130, 60, 31, 41));
        threeUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        threeUpPushButton->setFlat(false);
        sixUpPushButton = new QPushButton(groupBox);
        sixUpPushButton->setObjectName(QStringLiteral("sixUpPushButton"));
        sixUpPushButton->setGeometry(QRect(240, 60, 31, 41));
        sixUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        sixUpPushButton->setFlat(false);
        ctrlRightPushButton = new QPushButton(groupBox);
        ctrlRightPushButton->setObjectName(QStringLiteral("ctrlRightPushButton"));
        ctrlRightPushButton->setGeometry(QRect(520, 210, 41, 41));
        ctrlRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        jianPushButton = new QPushButton(groupBox);
        jianPushButton->setObjectName(QStringLiteral("jianPushButton"));
        jianPushButton->setGeometry(QRect(420, 60, 41, 41));
        jianPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        ePushButton = new QPushButton(groupBox);
        ePushButton->setObjectName(QStringLiteral("ePushButton"));
        ePushButton->setGeometry(QRect(140, 100, 41, 41));
        ePushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        vPushButton = new QPushButton(groupBox);
        vPushButton->setObjectName(QStringLiteral("vPushButton"));
        vPushButton->setGeometry(QRect(207, 170, 41, 41));
        vPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        jiaPushButton = new QPushButton(groupBox);
        jiaPushButton->setObjectName(QStringLiteral("jiaPushButton"));
        jiaPushButton->setGeometry(QRect(460, 60, 41, 41));
        jiaPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F8PushButton = new QPushButton(groupBox);
        F8PushButton->setObjectName(QStringLiteral("F8PushButton"));
        F8PushButton->setGeometry(QRect(360, 10, 41, 41));
        F8PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F8PushButton->setFlat(false);
        jPushButton = new QPushButton(groupBox);
        jPushButton->setObjectName(QStringLiteral("jPushButton"));
        jPushButton->setGeometry(QRect(300, 140, 41, 31));
        jPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        bPushButton = new QPushButton(groupBox);
        bPushButton->setObjectName(QStringLiteral("bPushButton"));
        bPushButton->setGeometry(QRect(250, 170, 41, 41));
        bPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        sPushButton = new QPushButton(groupBox);
        sPushButton->setObjectName(QStringLiteral("sPushButton"));
        sPushButton->setGeometry(QRect(122, 140, 41, 31));
        sPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        questionPushButtom = new QPushButton(groupBox);
        questionPushButtom->setObjectName(QStringLiteral("questionPushButtom"));
        questionPushButtom->setGeometry(QRect(430, 170, 41, 41));
        questionPushButtom->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        shiftLeftPushButton = new QPushButton(groupBox);
        shiftLeftPushButton->setObjectName(QStringLiteral("shiftLeftPushButton"));
        shiftLeftPushButton->setGeometry(QRect(10, 170, 91, 41));
        shiftLeftPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F3PushButton = new QPushButton(groupBox);
        F3PushButton->setObjectName(QStringLiteral("F3PushButton"));
        F3PushButton->setGeometry(QRect(150, 10, 41, 41));
        F3PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F3PushButton->setFlat(false);
        oPushButton = new QPushButton(groupBox);
        oPushButton->setObjectName(QStringLiteral("oPushButton"));
        oPushButton->setGeometry(QRect(360, 100, 41, 41));
        oPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        nineRightPushButton = new QPushButton(groupBox);
        nineRightPushButton->setObjectName(QStringLiteral("nineRightPushButton"));
        nineRightPushButton->setGeometry(QRect(780, 100, 41, 41));
        nineRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        pPushButton = new QPushButton(groupBox);
        pPushButton->setObjectName(QStringLiteral("pPushButton"));
        pPushButton->setGeometry(QRect(400, 100, 41, 41));
        pPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        xPushButton = new QPushButton(groupBox);
        xPushButton->setObjectName(QStringLiteral("xPushButton"));
        xPushButton->setGeometry(QRect(140, 170, 41, 41));
        xPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        nPushButton = new QPushButton(groupBox);
        nPushButton->setObjectName(QStringLiteral("nPushButton"));
        nPushButton->setGeometry(QRect(290, 170, 31, 41));
        nPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        enterRightPushButton = new QPushButton(groupBox);
        enterRightPushButton->setObjectName(QStringLiteral("enterRightPushButton"));
        enterRightPushButton->setGeometry(QRect(820, 170, 41, 81));
        enterRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        altLeftPushButton = new QPushButton(groupBox);
        altLeftPushButton->setObjectName(QStringLiteral("altLeftPushButton"));
        altLeftPushButton->setGeometry(QRect(100, 210, 51, 41));
        altLeftPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        oneUpPushButton = new QPushButton(groupBox);
        oneUpPushButton->setObjectName(QStringLiteral("oneUpPushButton"));
        oneUpPushButton->setGeometry(QRect(50, 60, 41, 41));
        oneUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        oneUpPushButton->setFlat(false);
        oneRightPushButton = new QPushButton(groupBox);
        oneRightPushButton->setObjectName(QStringLiteral("oneRightPushButton"));
        oneRightPushButton->setGeometry(QRect(702, 170, 41, 41));
        oneRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        insertPushButton = new QPushButton(groupBox);
        insertPushButton->setObjectName(QStringLiteral("insertPushButton"));
        insertPushButton->setGeometry(QRect(580, 60, 41, 41));
        insertPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        windowsLeftPushButton = new QPushButton(groupBox);
        windowsLeftPushButton->setObjectName(QStringLiteral("windowsLeftPushButton"));
        windowsLeftPushButton->setGeometry(QRect(60, 210, 41, 41));
        windowsLeftPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        spacePushButton = new QPushButton(groupBox);
        spacePushButton->setObjectName(QStringLiteral("spacePushButton"));
        spacePushButton->setGeometry(QRect(150, 210, 231, 41));
        spacePushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F2PushButton = new QPushButton(groupBox);
        F2PushButton->setObjectName(QStringLiteral("F2PushButton"));
        F2PushButton->setGeometry(QRect(120, 10, 41, 41));
        F2PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F2PushButton->setFlat(false);
        eightUpPushButton = new QPushButton(groupBox);
        eightUpPushButton->setObjectName(QStringLiteral("eightUpPushButton"));
        eightUpPushButton->setGeometry(QRect(310, 60, 41, 41));
        eightUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        key1PushButton = new QPushButton(groupBox);
        key1PushButton->setObjectName(QStringLiteral("key1PushButton"));
        key1PushButton->setGeometry(QRect(510, 100, 51, 41));
        key1PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        leftPushButton = new QPushButton(groupBox);
        leftPushButton->setObjectName(QStringLiteral("leftPushButton"));
        leftPushButton->setGeometry(QRect(580, 210, 41, 41));
        leftPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F10PushButton = new QPushButton(groupBox);
        F10PushButton->setObjectName(QStringLiteral("F10PushButton"));
        F10PushButton->setGeometry(QRect(450, 10, 41, 41));
        F10PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F10PushButton->setFlat(false);
        rightMulPushButton = new QPushButton(groupBox);
        rightMulPushButton->setObjectName(QStringLiteral("rightMulPushButton"));
        rightMulPushButton->setGeometry(QRect(780, 60, 41, 41));
        rightMulPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        zPushButton = new QPushButton(groupBox);
        zPushButton->setObjectName(QStringLiteral("zPushButton"));
        zPushButton->setGeometry(QRect(100, 170, 40, 41));
        zPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F6PushButton = new QPushButton(groupBox);
        F6PushButton->setObjectName(QStringLiteral("F6PushButton"));
        F6PushButton->setGeometry(QRect(280, 10, 41, 41));
        F6PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F6PushButton->setFlat(false);
        fiveRightPushButton = new QPushButton(groupBox);
        fiveRightPushButton->setObjectName(QStringLiteral("fiveRightPushButton"));
        fiveRightPushButton->setGeometry(QRect(740, 140, 42, 31));
        fiveRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        aPushButton = new QPushButton(groupBox);
        aPushButton->setObjectName(QStringLiteral("aPushButton"));
        aPushButton->setGeometry(QRect(83, 140, 41, 31));
        aPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        NumLockPushButton = new QPushButton(groupBox);
        NumLockPushButton->setObjectName(QStringLiteral("NumLockPushButton"));
        NumLockPushButton->setGeometry(QRect(700, 60, 41, 41));
        NumLockPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        pageUpPushButton = new QPushButton(groupBox);
        pageUpPushButton->setObjectName(QStringLiteral("pageUpPushButton"));
        pageUpPushButton->setGeometry(QRect(650, 60, 41, 41));
        pageUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        enterLeftPushButton = new QPushButton(groupBox);
        enterLeftPushButton->setObjectName(QStringLiteral("enterLeftPushButton"));
        enterLeftPushButton->setGeometry(QRect(490, 140, 71, 31));
        enterLeftPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F12PushButton = new QPushButton(groupBox);
        F12PushButton->setObjectName(QStringLiteral("F12PushButton"));
        F12PushButton->setGeometry(QRect(530, 12, 31, 41));
        F12PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F12PushButton->setFlat(false);
        semicolonPushButton = new QPushButton(groupBox);
        semicolonPushButton->setObjectName(QStringLiteral("semicolonPushButton"));
        semicolonPushButton->setGeometry(QRect(410, 140, 41, 31));
        semicolonPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F9PushButton = new QPushButton(groupBox);
        F9PushButton->setObjectName(QStringLiteral("F9PushButton"));
        F9PushButton->setGeometry(QRect(410, 10, 41, 41));
        F9PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F9PushButton->setFlat(false);
        downPushButton = new QPushButton(groupBox);
        downPushButton->setObjectName(QStringLiteral("downPushButton"));
        downPushButton->setGeometry(QRect(620, 210, 31, 41));
        downPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        kPushButton = new QPushButton(groupBox);
        kPushButton->setObjectName(QStringLiteral("kPushButton"));
        kPushButton->setGeometry(QRect(340, 140, 41, 31));
        kPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        fPushButton = new QPushButton(groupBox);
        fPushButton->setObjectName(QStringLiteral("fPushButton"));
        fPushButton->setGeometry(QRect(190, 140, 41, 31));
        fPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        iPushButton = new QPushButton(groupBox);
        iPushButton->setObjectName(QStringLiteral("iPushButton"));
        iPushButton->setGeometry(QRect(330, 100, 31, 41));
        iPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        zeroRightPushButton = new QPushButton(groupBox);
        zeroRightPushButton->setObjectName(QStringLiteral("zeroRightPushButton"));
        zeroRightPushButton->setGeometry(QRect(700, 210, 81, 41));
        zeroRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F1PushButton = new QPushButton(groupBox);
        F1PushButton->setObjectName(QStringLiteral("F1PushButton"));
        F1PushButton->setGeometry(QRect(80, 10, 41, 41));
        F1PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F1PushButton->setFlat(false);
        commaPushButton = new QPushButton(groupBox);
        commaPushButton->setObjectName(QStringLiteral("commaPushButton"));
        commaPushButton->setGeometry(QRect(360, 170, 35, 41));
        commaPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        fiveUpPushButton = new QPushButton(groupBox);
        fiveUpPushButton->setObjectName(QStringLiteral("fiveUpPushButton"));
        fiveUpPushButton->setGeometry(QRect(200, 60, 41, 41));
        fiveUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        fiveUpPushButton->setFlat(false);
        leftBracketPushButton = new QPushButton(groupBox);
        leftBracketPushButton->setObjectName(QStringLiteral("leftBracketPushButton"));
        leftBracketPushButton->setGeometry(QRect(440, 100, 41, 41));
        leftBracketPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        ScrollLockPushButton = new QPushButton(groupBox);
        ScrollLockPushButton->setObjectName(QStringLiteral("ScrollLockPushButton"));
        ScrollLockPushButton->setGeometry(QRect(620, 10, 31, 41));
        ScrollLockPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        ScrollLockPushButton->setFlat(false);
        F5PushButton = new QPushButton(groupBox);
        F5PushButton->setObjectName(QStringLiteral("F5PushButton"));
        F5PushButton->setGeometry(QRect(240, 10, 41, 41));
        F5PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F5PushButton->setFlat(false);
        fourRightPushButton = new QPushButton(groupBox);
        fourRightPushButton->setObjectName(QStringLiteral("fourRightPushButton"));
        fourRightPushButton->setGeometry(QRect(702, 140, 41, 31));
        fourRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        rightSubPushButton = new QPushButton(groupBox);
        rightSubPushButton->setObjectName(QStringLiteral("rightSubPushButton"));
        rightSubPushButton->setGeometry(QRect(819, 60, 41, 41));
        rightSubPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        twoUpPushButton = new QPushButton(groupBox);
        twoUpPushButton->setObjectName(QStringLiteral("twoUpPushButton"));
        twoUpPushButton->setGeometry(QRect(90, 60, 41, 41));
        twoUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        twoUpPushButton->setFlat(false);
        tabPushButton = new QPushButton(groupBox);
        tabPushButton->setObjectName(QStringLiteral("tabPushButton"));
        tabPushButton->setGeometry(QRect(10, 100, 61, 41));
        tabPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        gPushButton = new QPushButton(groupBox);
        gPushButton->setObjectName(QStringLiteral("gPushButton"));
        gPushButton->setGeometry(QRect(230, 140, 41, 31));
        gPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        PauseBreakPushButton = new QPushButton(groupBox);
        PauseBreakPushButton->setObjectName(QStringLiteral("PauseBreakPushButton"));
        PauseBreakPushButton->setGeometry(QRect(650, 10, 41, 41));
        PauseBreakPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        PauseBreakPushButton->setFlat(false);
        threeRightPushButton = new QPushButton(groupBox);
        threeRightPushButton->setObjectName(QStringLiteral("threeRightPushButton"));
        threeRightPushButton->setGeometry(QRect(780, 170, 41, 41));
        threeRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        nineUpPushButton = new QPushButton(groupBox);
        nineUpPushButton->setObjectName(QStringLiteral("nineUpPushButton"));
        nineUpPushButton->setGeometry(QRect(350, 60, 31, 41));
        nineUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        sevenUpPushButton = new QPushButton(groupBox);
        sevenUpPushButton->setObjectName(QStringLiteral("sevenUpPushButton"));
        sevenUpPushButton->setGeometry(QRect(270, 60, 41, 41));
        sevenUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        sevenUpPushButton->setFlat(false);
        qPushButton = new QPushButton(groupBox);
        qPushButton->setObjectName(QStringLiteral("qPushButton"));
        qPushButton->setGeometry(QRect(70, 100, 41, 41));
        qPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        windowsRightPushButton = new QPushButton(groupBox);
        windowsRightPushButton->setObjectName(QStringLiteral("windowsRightPushButton"));
        windowsRightPushButton->setGeometry(QRect(430, 210, 41, 41));
        windowsRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F7PushButton = new QPushButton(groupBox);
        F7PushButton->setObjectName(QStringLiteral("F7PushButton"));
        F7PushButton->setGeometry(QRect(320, 10, 41, 41));
        F7PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F7PushButton->setFlat(false);
        lPushButton = new QPushButton(groupBox);
        lPushButton->setObjectName(QStringLiteral("lPushButton"));
        lPushButton->setGeometry(QRect(380, 140, 41, 31));
        lPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        rPushButton = new QPushButton(groupBox);
        rPushButton->setObjectName(QStringLiteral("rPushButton"));
        rPushButton->setGeometry(QRect(180, 100, 41, 41));
        rPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F4PushButton = new QPushButton(groupBox);
        F4PushButton->setObjectName(QStringLiteral("F4PushButton"));
        F4PushButton->setGeometry(QRect(190, 10, 41, 41));
        F4PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F4PushButton->setFlat(false);
        cPushButton = new QPushButton(groupBox);
        cPushButton->setObjectName(QStringLiteral("cPushButton"));
        cPushButton->setGeometry(QRect(178, 170, 31, 41));
        cPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        ctrlLeftPushButton = new QPushButton(groupBox);
        ctrlLeftPushButton->setObjectName(QStringLiteral("ctrlLeftPushButton"));
        ctrlLeftPushButton->setGeometry(QRect(10, 210, 51, 41));
        ctrlLeftPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        spotPushButton = new QPushButton(groupBox);
        spotPushButton->setObjectName(QStringLiteral("spotPushButton"));
        spotPushButton->setGeometry(QRect(390, 170, 41, 41));
        spotPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        rightPushButton = new QPushButton(groupBox);
        rightPushButton->setObjectName(QStringLiteral("rightPushButton"));
        rightPushButton->setGeometry(QRect(650, 210, 41, 41));
        rightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        yPushButton = new QPushButton(groupBox);
        yPushButton->setObjectName(QStringLiteral("yPushButton"));
        yPushButton->setGeometry(QRect(250, 100, 41, 41));
        yPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        homePushButton = new QPushButton(groupBox);
        homePushButton->setObjectName(QStringLiteral("homePushButton"));
        homePushButton->setGeometry(QRect(620, 60, 31, 41));
        homePushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        pageDownPushButton = new QPushButton(groupBox);
        pageDownPushButton->setObjectName(QStringLiteral("pageDownPushButton"));
        pageDownPushButton->setGeometry(QRect(650, 100, 41, 41));
        pageDownPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        tPushButton = new QPushButton(groupBox);
        tPushButton->setObjectName(QStringLiteral("tPushButton"));
        tPushButton->setGeometry(QRect(220, 100, 31, 41));
        tPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F11PushButton = new QPushButton(groupBox);
        F11PushButton->setObjectName(QStringLiteral("F11PushButton"));
        F11PushButton->setGeometry(QRect(490, 10, 41, 41));
        F11PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        F11PushButton->setFlat(false);
        shiftRightPushButton = new QPushButton(groupBox);
        shiftRightPushButton->setObjectName(QStringLiteral("shiftRightPushButton"));
        shiftRightPushButton->setGeometry(QRect(470, 170, 91, 41));
        shiftRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        hPushButton = new QPushButton(groupBox);
        hPushButton->setObjectName(QStringLiteral("hPushButton"));
        hPushButton->setGeometry(QRect(268, 140, 41, 31));
        hPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        dPushButton = new QPushButton(groupBox);
        dPushButton->setObjectName(QStringLiteral("dPushButton"));
        dPushButton->setGeometry(QRect(160, 140, 31, 31));
        dPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        altRightPushButton = new QPushButton(groupBox);
        altRightPushButton->setObjectName(QStringLiteral("altRightPushButton"));
        altRightPushButton->setGeometry(QRect(380, 210, 51, 41));
        altRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        delRightPushButton = new QPushButton(groupBox);
        delRightPushButton->setObjectName(QStringLiteral("delRightPushButton"));
        delRightPushButton->setGeometry(QRect(780, 210, 41, 41));
        delRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        rightBracketPushButton = new QPushButton(groupBox);
        rightBracketPushButton->setObjectName(QStringLiteral("rightBracketPushButton"));
        rightBracketPushButton->setGeometry(QRect(470, 100, 41, 41));
        rightBracketPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        sixRightPushButton = new QPushButton(groupBox);
        sixRightPushButton->setObjectName(QStringLiteral("sixRightPushButton"));
        sixRightPushButton->setGeometry(QRect(780, 140, 41, 31));
        sixRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        capsLockPushButton = new QPushButton(groupBox);
        capsLockPushButton->setObjectName(QStringLiteral("capsLockPushButton"));
        capsLockPushButton->setGeometry(QRect(10, 140, 81, 31));
        capsLockPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        wPushButton = new QPushButton(groupBox);
        wPushButton->setObjectName(QStringLiteral("wPushButton"));
        wPushButton->setGeometry(QRect(100, 100, 41, 41));
        wPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        mPushButton = new QPushButton(groupBox);
        mPushButton->setObjectName(QStringLiteral("mPushButton"));
        mPushButton->setGeometry(QRect(320, 170, 41, 41));
        mPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        uPushButton = new QPushButton(groupBox);
        uPushButton->setObjectName(QStringLiteral("uPushButton"));
        uPushButton->setGeometry(QRect(290, 100, 41, 41));
        uPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        endPushButton = new QPushButton(groupBox);
        endPushButton->setObjectName(QStringLiteral("endPushButton"));
        endPushButton->setGeometry(QRect(620, 100, 31, 41));
        endPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        key2PushButton = new QPushButton(groupBox);
        key2PushButton->setObjectName(QStringLiteral("key2PushButton"));
        key2PushButton->setGeometry(QRect(470, 210, 51, 41));
        key2PushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        fourUpPushButton = new QPushButton(groupBox);
        fourUpPushButton->setObjectName(QStringLiteral("fourUpPushButton"));
        fourUpPushButton->setGeometry(QRect(160, 60, 41, 41));
        fourUpPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        fourUpPushButton->setFlat(false);
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, -10, 869, 281));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/resources/keyboard1.png")));
        eightRightPushButton = new QPushButton(groupBox);
        eightRightPushButton->setObjectName(QStringLiteral("eightRightPushButton"));
        eightRightPushButton->setGeometry(QRect(740, 100, 41, 41));
        eightRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        jiaRightPushButton = new QPushButton(groupBox);
        jiaRightPushButton->setObjectName(QStringLiteral("jiaRightPushButton"));
        jiaRightPushButton->setGeometry(QRect(820, 100, 41, 71));
        jiaRightPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        PrintScreenPushButton = new QPushButton(groupBox);
        PrintScreenPushButton->setObjectName(QStringLiteral("PrintScreenPushButton"));
        PrintScreenPushButton->setGeometry(QRect(580, 10, 41, 41));
        PrintScreenPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        PrintScreenPushButton->setFlat(false);
        backPushButton = new QPushButton(groupBox);
        backPushButton->setObjectName(QStringLiteral("backPushButton"));
        backPushButton->setGeometry(QRect(500, 60, 61, 41));
        backPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        colonPushButton = new QPushButton(groupBox);
        colonPushButton->setObjectName(QStringLiteral("colonPushButton"));
        colonPushButton->setGeometry(QRect(450, 140, 41, 31));
        colonPushButton->setStyleSheet(QStringLiteral("QPushButton{background: transparent;}"));
        label->raise();
        deletePushButton->raise();
        upPushButton->raise();
        titlePushButton->raise();
        EscPushButton->raise();
        twoRightPushButton->raise();
        rightDivisionPushButton->raise();
        zeroUpPushButton->raise();
        sevenRightPushButton->raise();
        threeUpPushButton->raise();
        sixUpPushButton->raise();
        ctrlRightPushButton->raise();
        jianPushButton->raise();
        ePushButton->raise();
        vPushButton->raise();
        jiaPushButton->raise();
        F8PushButton->raise();
        jPushButton->raise();
        bPushButton->raise();
        sPushButton->raise();
        questionPushButtom->raise();
        shiftLeftPushButton->raise();
        F3PushButton->raise();
        oPushButton->raise();
        nineRightPushButton->raise();
        pPushButton->raise();
        xPushButton->raise();
        nPushButton->raise();
        enterRightPushButton->raise();
        altLeftPushButton->raise();
        oneUpPushButton->raise();
        oneRightPushButton->raise();
        insertPushButton->raise();
        windowsLeftPushButton->raise();
        spacePushButton->raise();
        F2PushButton->raise();
        eightUpPushButton->raise();
        key1PushButton->raise();
        leftPushButton->raise();
        F10PushButton->raise();
        rightMulPushButton->raise();
        zPushButton->raise();
        F6PushButton->raise();
        fiveRightPushButton->raise();
        aPushButton->raise();
        NumLockPushButton->raise();
        pageUpPushButton->raise();
        enterLeftPushButton->raise();
        F12PushButton->raise();
        semicolonPushButton->raise();
        F9PushButton->raise();
        downPushButton->raise();
        kPushButton->raise();
        fPushButton->raise();
        iPushButton->raise();
        zeroRightPushButton->raise();
        F1PushButton->raise();
        commaPushButton->raise();
        fiveUpPushButton->raise();
        leftBracketPushButton->raise();
        ScrollLockPushButton->raise();
        F5PushButton->raise();
        fourRightPushButton->raise();
        rightSubPushButton->raise();
        twoUpPushButton->raise();
        tabPushButton->raise();
        gPushButton->raise();
        PauseBreakPushButton->raise();
        threeRightPushButton->raise();
        nineUpPushButton->raise();
        sevenUpPushButton->raise();
        qPushButton->raise();
        windowsRightPushButton->raise();
        F7PushButton->raise();
        lPushButton->raise();
        rPushButton->raise();
        F4PushButton->raise();
        cPushButton->raise();
        ctrlLeftPushButton->raise();
        spotPushButton->raise();
        rightPushButton->raise();
        yPushButton->raise();
        homePushButton->raise();
        pageDownPushButton->raise();
        tPushButton->raise();
        F11PushButton->raise();
        shiftRightPushButton->raise();
        hPushButton->raise();
        dPushButton->raise();
        altRightPushButton->raise();
        delRightPushButton->raise();
        rightBracketPushButton->raise();
        sixRightPushButton->raise();
        capsLockPushButton->raise();
        wPushButton->raise();
        mPushButton->raise();
        uPushButton->raise();
        endPushButton->raise();
        key2PushButton->raise();
        fourUpPushButton->raise();
        eightRightPushButton->raise();
        jiaRightPushButton->raise();
        PrintScreenPushButton->raise();
        backPushButton->raise();
        colonPushButton->raise();

        gridLayout_4->addWidget(groupBox, 1, 1, 2, 1);

        horizontalSpacer_4 = new QSpacerItem(333, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_4, 1, 2, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(334, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_3, 2, 0, 1, 1);

        verticalSpacer_17 = new QSpacerItem(20, 228, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_4->addItem(verticalSpacer_17, 3, 1, 1, 1);

        testWidget->addTab(tab, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName(QStringLiteral("tab_10"));
        comboBox = new QComboBox(tab_10);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(150, 150, 110, 20));
        comboBox->setStyleSheet(QLatin1String("QComboBox {\n"
"      border: 1px solid gray;\n"
"      border-radius: 3px;\n"
"      padding: 1px 18px 1px 3px;\n"
"      min-width: 4em;\n"
"}\n"
"\n"
"QComboBox:editable {\n"
"      background: white;\n"
"}\n"
"\n"
"QComboBox:!editable, QComboBox::drop-down:editable {\n"
"       background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                   stop: 0 #E1E1E1, stop: 0.4 #DDDDDD,\n"
"                                   stop: 0.5 #D8D8D8, stop: 1.0 #D3D3D3);\n"
"}\n"
"\n"
"  /* QComboBox gets the \"on\" state when the popup is open */\n"
"QComboBox:!editable:on, QComboBox::drop-down:editable:on {\n"
"      background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                  stop: 0 #D3D3D3, stop: 0.4 #D8D8D8,\n"
"                                  stop: 0.5 #DDDDDD, stop: 1.0 #E1E1E1);\n"
"}\n"
"\n"
"QComboBox:on { /* shift the text when the popup opens */\n"
"      padding-top: 3px;\n"
"      padding-left: 4px;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    "
                        "  subcontrol-origin: padding;\n"
"      subcontrol-position: top right;\n"
"      width: 15px;\n"
"\n"
"      border-left-width: 1px;\n"
"      border-left-color: darkgray;\n"
"      border-left-style: solid; /* just a single line */\n"
"      border-top-right-radius: 3px; /* same radius as the QComboBox */\n"
"      border-bottom-right-radius: 3px;\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"	image: url(:/images/resources/1downarrow.ico);\n"
"}\n"
"\n"
"  QComboBox::down-arrow:on { /* shift the arrow when popup is open */\n"
"      top: 1px;\n"
"      left: 1px;\n"
"  }"));
        comboBox->setIconSize(QSize(16, 16));
        testWidget->addTab(tab_10, QString());

        gridLayout->addWidget(testWidget, 0, 3, 1, 1);


        retranslateUi(Widget);

        testWidget->setCurrentIndex(5);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "\347\246\276\350\276\276\350\212\257\345\276\256", 0));
        Widget->setProperty("class", QVariant(QString()));
        test->setProperty("class", QVariant(QApplication::translate("Widget", "test", 0)));
        errorLabel_2->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#f0f0f0;\">\351\224\231\350\257\257\347\264\257\347\247\257\357\274\232</span></p></body></html>", 0));
        errorCnt->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600; color:#f5f5f5;\">0</span></p></body></html>", 0));
        timeLabel->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:12pt; color:#f5f5f5;\">\345\267\262\346\265\213\346\227\266\351\227\264\357\274\232</span></p></body></html>", 0));
        timeCnt->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-weight:600; color:#f5f5f5;\">00:00:00</span></p></body></html>", 0));
        errorLabel->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:12pt; color:#f5f5f5;\">\345\276\252\347\216\257\346\265\213\350\257\225\346\254\241\346\225\260\357\274\232</span></p></body></html>", 0));
        circleCnt->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600; color:#f5f5f5;\">0</span></p></body></html>", 0));
        circleButton->setText(QApplication::translate("Widget", "\345\276\252\347\216\257\346\265\213\350\257\225", 0));
        deleteLogButton->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\346\265\213\350\257\225\346\212\245\345\221\212", 0));
        label_7->setText(QString());
        checkLogButton->setText(QApplication::translate("Widget", "\346\237\245\347\234\213\346\265\213\350\257\225\346\212\245\345\221\212", 0));
        SideBar->setProperty("class", QVariant(QApplication::translate("Widget", "SideBar", 0)));
        widget->setProperty("class", QVariant(QApplication::translate("Widget", "Separator", 0)));
        toolButton_kbdlite->setText(QApplication::translate("Widget", "\347\251\272\347\231\275\347\203\255\351\224\256", 0));
        toolButton_mouse->setText(QApplication::translate("Widget", "\351\274\240\346\240\207\346\265\213\350\257\225", 0));
        toolButton_kbd->setText(QApplication::translate("Widget", "\351\224\256\347\233\230\346\265\213\350\257\225", 0));
        toolButton_ram->setText(QApplication::translate("Widget", "\345\206\205\345\255\230\346\265\213\350\257\225", 0));
        toolButton_disk->setText(QApplication::translate("Widget", "\347\243\201\347\233\230\346\265\213\350\257\225", 0));
        toolButton_pic->setText(QApplication::translate("Widget", "2D/3D\346\265\213\350\257\225", 0));
        toolButton_net->setText(QApplication::translate("Widget", "\347\275\221\345\215\241\346\265\213\350\257\225", 0));
        toolButton_uart->setText(QApplication::translate("Widget", "\344\270\262\345\217\243\346\265\213\350\257\225", 0));
        checkBox1->setText(QString());
        checkBox2->setText(QString());
        checkBox3->setText(QString());
        checkBox4->setText(QString());
        checkBox5->setText(QString());
        testWidget->setProperty("class", QVariant(QApplication::translate("Widget", "tabWidget", 0)));
        pushButton1->setText(QString());
        pushButton2->setText(QString());
        pushButton3->setText(QString());
        pushButton4->setText(QString());
        pushButton5->setText(QString());
        pushButton6->setText(QString());
        pushButton7->setText(QString());
        pushButton8->setText(QString());
        label_13->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt; color:#eaeaea;\">\345\206\205\345\255\230\350\257\273\345\206\231\357\274\232</span></p></body></html>", 0));
        label_14->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt; color:#eaeaea;\">\345\206\205\345\255\230\346\265\213\350\257\225\357\274\214\346\255\243\345\234\250\350\277\233\350\241\214\344\270\255......</span></p></body></html>", 0));
        pushButton_111->setText(QString());
        pushButton_112->setText(QString());
        pushButton_113->setText(QString());
        pushButton_114->setText(QString());
        pushButton_115->setText(QString());
        pushButton_116->setText(QString());
        pushButton_117->setText(QString());
        pushButton_118->setText(QString());
        pushButton9->setText(QString());
        pushButton10->setText(QString());
        pushButton11->setText(QString());
        pushButton12->setText(QString());
        pushButton13->setText(QString());
        pushButton14->setText(QString());
        pushButton15->setText(QString());
        pushButton16->setText(QString());
        pushButton25->setText(QString());
        pushButton26->setText(QString());
        pushButton27->setText(QString());
        pushButton28->setText(QString());
        pushButton29->setText(QString());
        pushButton30->setText(QString());
        pushButton31->setText(QString());
        pushButton32->setText(QString());
        pushButton17->setText(QString());
        pushButton18->setText(QString());
        pushButton19->setText(QString());
        pushButton20->setText(QString());
        pushButton21->setText(QString());
        pushButton22->setText(QString());
        pushButton23->setText(QString());
        pushButton24->setText(QString());
        pushButton33->setText(QString());
        pushButton34->setText(QString());
        pushButton35->setText(QString());
        pushButton36->setText(QString());
        pushButton37->setText(QString());
        pushButton38->setText(QString());
        pushButton39->setText(QString());
        pushButton40->setText(QString());
        testWidget->setTabText(testWidget->indexOf(tab_6), QApplication::translate("Widget", "tab 6", 0));
        label_16->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\345\206\231\346\265\213\350\257\225\357\274\232</span></p></body></html>", 0));
        pushButton_95->setText(QString());
        pushButton_96->setText(QString());
        pushButton_97->setText(QString());
        pushButton_98->setText(QString());
        pushButton_99->setText(QString());
        pushButton_100->setText(QString());
        pushButton_101->setText(QString());
        pushButton_102->setText(QString());
        pushButton_41->setText(QString());
        pushButton_42->setText(QString());
        pushButton_43->setText(QString());
        pushButton_44->setText(QString());
        pushButton_45->setText(QString());
        pushButton_46->setText(QString());
        pushButton_47->setText(QString());
        pushButton_48->setText(QString());
        pushButton_71->setText(QString());
        pushButton_72->setText(QString());
        pushButton_73->setText(QString());
        pushButton_74->setText(QString());
        pushButton_75->setText(QString());
        pushButton_76->setText(QString());
        pushButton_77->setText(QString());
        pushButton_78->setText(QString());
        label_17->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt; color:#eaeaea;\">\347\243\201\347\233\230\346\265\213\350\257\225\357\274\214\346\255\243\345\234\250\350\277\233\350\241\214\344\270\255......</span></p></body></html>", 0));
        label_15->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\350\257\273\346\265\213\350\257\225\357\274\232</span></p></body></html>", 0));
        pushButton41->setText(QString());
        pushButton42->setText(QString());
        pushButton43->setText(QString());
        pushButton44->setText(QString());
        pushButton45->setText(QString());
        pushButton46->setText(QString());
        pushButton47->setText(QString());
        pushButton48->setText(QString());
        pushButton_79->setText(QString());
        pushButton_80->setText(QString());
        pushButton_81->setText(QString());
        pushButton_82->setText(QString());
        pushButton_83->setText(QString());
        pushButton_84->setText(QString());
        pushButton_85->setText(QString());
        pushButton_86->setText(QString());
        pushButton49->setText(QString());
        pushButton50->setText(QString());
        pushButton51->setText(QString());
        pushButton52->setText(QString());
        pushButton53->setText(QString());
        pushButton54->setText(QString());
        pushButton55->setText(QString());
        pushButton56->setText(QString());
        testWidget->setTabText(testWidget->indexOf(tab_9), QApplication::translate("Widget", "tab_9", 0));
        label_4->setText(QApplication::translate("Widget", "TextLabel", 0));
        testWidget->setTabText(testWidget->indexOf(tab_3), QApplication::translate("Widget", "Tab 3", 0));
        label_12->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#eaeaea;\">\347\275\221\347\273\234\346\265\213\350\257\225\357\274\214\346\255\243\345\234\250\350\277\233\350\241\214\344\270\255......</span></p></body></html>", 0));
        testWidget->setTabText(testWidget->indexOf(tab_4), QApplication::translate("Widget", "Tab 4", 0));
        label_28->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#eaeaea;\">\344\270\262\345\217\243\346\265\213\350\257\225\357\274\214\346\255\243\345\234\250\350\277\233\350\241\214\344\270\255......</span></p></body></html>", 0));
        label_18->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\345\217\221\351\200\201\346\225\260\346\215\256\357\274\232</span></p></body></html>", 0));
        label_19->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\346\216\245\346\224\266\346\225\260\346\215\256\357\274\232</span></p></body></html>", 0));
        label_20->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\345\217\221\351\200\201\346\225\260\346\215\256\357\274\232</span></p></body></html>", 0));
        label_21->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\346\216\245\346\224\266\346\225\260\346\215\256\357\274\232</span></p></body></html>", 0));
        label_23->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\345\217\221\351\200\201\346\225\260\346\215\256\357\274\232</span></p></body></html>", 0));
        label_22->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">\346\216\245\346\224\266\346\225\260\346\215\256\357\274\232</span></p></body></html>", 0));
        uart_label->setText(QApplication::translate("Widget", "TextLabel", 0));
        testWidget->setTabText(testWidget->indexOf(tab_5), QApplication::translate("Widget", "Tab 5", 0));
        groupBox_3->setTitle(QApplication::translate("Widget", "\351\224\256\345\200\274\350\257\242\351\227\256\347\240\201", 0));
        k5PushButton->setText(QApplication::translate("Widget", "K5", 0));
        k6PushButton->setText(QApplication::translate("Widget", "K6", 0));
        k7PushButton->setText(QApplication::translate("Widget", "K7", 0));
        k8PushButton->setText(QApplication::translate("Widget", "K8", 0));
        k9PushButton->setText(QApplication::translate("Widget", "K9", 0));
        k10PushButton->setText(QApplication::translate("Widget", "K10", 0));
        k11PushButton->setText(QApplication::translate("Widget", "K11", 0));
        k12PushButton->setText(QApplication::translate("Widget", "K12", 0));
        k13PushButton->setText(QApplication::translate("Widget", "K13", 0));
        k14PushButton->setText(QApplication::translate("Widget", "K14", 0));
        k15PushButton->setText(QApplication::translate("Widget", "K15", 0));
        k16PushButton->setText(QApplication::translate("Widget", "K16", 0));
        k12LineEdit->setText(QString());
        k1PushButton->setText(QApplication::translate("Widget", "K1", 0));
        k4PushButton->setText(QApplication::translate("Widget", "K4", 0));
        k2PushButton->setText(QApplication::translate("Widget", "K2", 0));
        k3PushButton->setText(QApplication::translate("Widget", "K3", 0));
        QueryCodePushButton->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\351\224\256\345\200\274\350\257\242\351\227\256\347\240\201", 0));
        clearrecPushButton->setText(QApplication::translate("Widget", "\346\270\205\351\231\244\350\257\242\351\227\256\347\240\201", 0));
        groupBox_2->setTitle(QApplication::translate("Widget", "\345\275\223\345\211\215\347\212\266\346\200\201\351\224\256\351\224\256\345\200\274\357\274\232", 0));
        keyTextEdit->setHtml(QApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'SimSun';\"><br /></p></body></html>", 0));
        queryclearPushButton->setText(QApplication::translate("Widget", "\346\270\205\351\231\244", 0));
        getPushButton->setText(QApplication::translate("Widget", "\350\216\267\345\217\226USB\350\256\276\345\244\207", 0));
        groupBox_4->setTitle(QApplication::translate("Widget", "USB\350\256\276\345\244\207", 0));
        label_9->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">PID:</span></p></body></html>", 0));
        label_10->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" color:#eaeaea;\">VID:</span></p></body></html>", 0));
        testWidget->setTabText(testWidget->indexOf(tab_7), QApplication::translate("Widget", "tab 7", 0));
        label_5->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600; color:#eaeaea;\">\351\274\240\346\240\207\345\235\220\346\240\207\357\274\232</span></p></body></html>", 0));
        leftButton->setText(QString());
        midButton->setText(QString());
        rightButton->setText(QString());
        testWidget->setTabText(testWidget->indexOf(tab_8), QApplication::translate("Widget", "tab 8", 0));
        label_2->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-weight:600; color:#eaeaea;\">\346\265\213\350\257\225\346\212\245\345\221\212\357\274\232</span></p></body></html>", 0));
        testWidget->setTabText(testWidget->indexOf(tab_11), QApplication::translate("Widget", "tab9", 0));
        groupBox->setTitle(QString());
        deletePushButton->setText(QString());
        upPushButton->setText(QString());
        titlePushButton->setText(QString());
        EscPushButton->setText(QString());
        twoRightPushButton->setText(QString());
        rightDivisionPushButton->setText(QString());
        zeroUpPushButton->setText(QString());
        sevenRightPushButton->setText(QString());
        threeUpPushButton->setText(QString());
        sixUpPushButton->setText(QString());
        ctrlRightPushButton->setText(QString());
        jianPushButton->setText(QString());
        ePushButton->setText(QString());
        vPushButton->setText(QString());
        jiaPushButton->setText(QString());
        F8PushButton->setText(QString());
        jPushButton->setText(QString());
        bPushButton->setText(QString());
        sPushButton->setText(QString());
        questionPushButtom->setText(QString());
        shiftLeftPushButton->setText(QString());
        F3PushButton->setText(QString());
        oPushButton->setText(QString());
        nineRightPushButton->setText(QString());
        pPushButton->setText(QString());
        xPushButton->setText(QString());
        nPushButton->setText(QString());
        enterRightPushButton->setText(QString());
        altLeftPushButton->setText(QString());
        oneUpPushButton->setText(QString());
        oneRightPushButton->setText(QString());
        insertPushButton->setText(QString());
        windowsLeftPushButton->setText(QString());
        spacePushButton->setText(QString());
        F2PushButton->setText(QString());
        eightUpPushButton->setText(QString());
        key1PushButton->setText(QString());
        leftPushButton->setText(QString());
        F10PushButton->setText(QString());
        rightMulPushButton->setText(QString());
        zPushButton->setText(QString());
        F6PushButton->setText(QString());
        fiveRightPushButton->setText(QString());
        aPushButton->setText(QString());
        NumLockPushButton->setText(QString());
        pageUpPushButton->setText(QString());
        enterLeftPushButton->setText(QString());
        F12PushButton->setText(QString());
        semicolonPushButton->setText(QString());
        F9PushButton->setText(QString());
        downPushButton->setText(QString());
        kPushButton->setText(QString());
        fPushButton->setText(QString());
        iPushButton->setText(QString());
        zeroRightPushButton->setText(QString());
        F1PushButton->setText(QString());
        commaPushButton->setText(QString());
        fiveUpPushButton->setText(QString());
        leftBracketPushButton->setText(QString());
        ScrollLockPushButton->setText(QString());
        F5PushButton->setText(QString());
        fourRightPushButton->setText(QString());
        rightSubPushButton->setText(QString());
        twoUpPushButton->setText(QString());
        tabPushButton->setText(QString());
        gPushButton->setText(QString());
        PauseBreakPushButton->setText(QString());
        threeRightPushButton->setText(QString());
        nineUpPushButton->setText(QString());
        sevenUpPushButton->setText(QString());
        qPushButton->setText(QString());
        windowsRightPushButton->setText(QString());
        F7PushButton->setText(QString());
        lPushButton->setText(QString());
        rPushButton->setText(QString());
        F4PushButton->setText(QString());
        cPushButton->setText(QString());
        ctrlLeftPushButton->setText(QString());
        spotPushButton->setText(QString());
        rightPushButton->setText(QString());
        yPushButton->setText(QString());
        homePushButton->setText(QString());
        pageDownPushButton->setText(QString());
        tPushButton->setText(QString());
        F11PushButton->setText(QString());
        shiftRightPushButton->setText(QString());
        hPushButton->setText(QString());
        dPushButton->setText(QString());
        altRightPushButton->setText(QString());
        delRightPushButton->setText(QString());
        rightBracketPushButton->setText(QString());
        sixRightPushButton->setText(QString());
        capsLockPushButton->setText(QString());
        wPushButton->setText(QString());
        mPushButton->setText(QString());
        uPushButton->setText(QString());
        endPushButton->setText(QString());
        key2PushButton->setText(QString());
        fourUpPushButton->setText(QString());
        label->setText(QString());
        eightRightPushButton->setText(QString());
        jiaRightPushButton->setText(QString());
        PrintScreenPushButton->setText(QString());
        backPushButton->setText(QString());
        colonPushButton->setText(QString());
        testWidget->setTabText(testWidget->indexOf(tab), QApplication::translate("Widget", "tab10", 0));
        testWidget->setTabText(testWidget->indexOf(tab_10), QApplication::translate("Widget", "\351\241\265", 0));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
