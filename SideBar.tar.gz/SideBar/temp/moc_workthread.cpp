/****************************************************************************
** Meta object code from reading C++ file 'workthread.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/workthread.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'workthread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_myThread_t {
    QByteArrayData data[14];
    char stringdata0[147];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_myThread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_myThread_t qt_meta_stringdata_myThread = {
    {
QT_MOC_LITERAL(0, 0, 8), // "myThread"
QT_MOC_LITERAL(1, 9, 9), // "ramSignal"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 10), // "diskSignal"
QT_MOC_LITERAL(4, 31, 9), // "picSignal"
QT_MOC_LITERAL(5, 41, 9), // "netSignal"
QT_MOC_LITERAL(6, 51, 10), // "uartSignal"
QT_MOC_LITERAL(7, 62, 17), // "sendKeyDataSignal"
QT_MOC_LITERAL(8, 80, 14), // "unsigned char*"
QT_MOC_LITERAL(9, 95, 6), // "KeyBuf"
QT_MOC_LITERAL(10, 102, 22), // "sendKeyQueryDataSignal"
QT_MOC_LITERAL(11, 125, 6), // "keyBuf"
QT_MOC_LITERAL(12, 132, 10), // "getTestFlg"
QT_MOC_LITERAL(13, 143, 3) // "flg"

    },
    "myThread\0ramSignal\0\0diskSignal\0picSignal\0"
    "netSignal\0uartSignal\0sendKeyDataSignal\0"
    "unsigned char*\0KeyBuf\0sendKeyQueryDataSignal\0"
    "keyBuf\0getTestFlg\0flg"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_myThread[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   54,    2, 0x06 /* Public */,
       3,    0,   55,    2, 0x06 /* Public */,
       4,    0,   56,    2, 0x06 /* Public */,
       5,    0,   57,    2, 0x06 /* Public */,
       6,    0,   58,    2, 0x06 /* Public */,
       7,    1,   59,    2, 0x06 /* Public */,
      10,    1,   62,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    1,   65,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 8,   11,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   13,

       0        // eod
};

void myThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        myThread *_t = static_cast<myThread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->ramSignal(); break;
        case 1: _t->diskSignal(); break;
        case 2: _t->picSignal(); break;
        case 3: _t->netSignal(); break;
        case 4: _t->uartSignal(); break;
        case 5: _t->sendKeyDataSignal((*reinterpret_cast< unsigned char*(*)>(_a[1]))); break;
        case 6: _t->sendKeyQueryDataSignal((*reinterpret_cast< unsigned char*(*)>(_a[1]))); break;
        case 7: _t->getTestFlg((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (myThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::ramSignal)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (myThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::diskSignal)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (myThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::picSignal)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (myThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::netSignal)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (myThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::uartSignal)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (myThread::*_t)(unsigned char * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::sendKeyDataSignal)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (myThread::*_t)(unsigned char * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&myThread::sendKeyQueryDataSignal)) {
                *result = 6;
                return;
            }
        }
    }
}

const QMetaObject myThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_myThread.data,
      qt_meta_data_myThread,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *myThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *myThread::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_myThread.stringdata0))
        return static_cast<void*>(const_cast< myThread*>(this));
    return QThread::qt_metacast(_clname);
}

int myThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void myThread::ramSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void myThread::diskSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void myThread::picSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void myThread::netSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void myThread::uartSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}

// SIGNAL 5
void myThread::sendKeyDataSignal(unsigned char * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void myThread::sendKeyQueryDataSignal(unsigned char * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_END_MOC_NAMESPACE
