/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/widget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Widget_t {
    QByteArrayData data[44];
    char stringdata0[736];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Widget"
QT_MOC_LITERAL(1, 7, 13), // "changeTestFlg"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 14), // "changeTimeDate"
QT_MOC_LITERAL(4, 37, 3), // "Tim"
QT_MOC_LITERAL(5, 41, 15), // "changefaultDate"
QT_MOC_LITERAL(6, 57, 4), // "date"
QT_MOC_LITERAL(7, 62, 16), // "changeCircleDate"
QT_MOC_LITERAL(8, 79, 9), // "onTimeout"
QT_MOC_LITERAL(9, 89, 18), // "changeButtonStatus"
QT_MOC_LITERAL(10, 108, 22), // "changePushButtonStatus"
QT_MOC_LITERAL(11, 131, 17), // "changePrintButton"
QT_MOC_LITERAL(12, 149, 22), // "toolButton_Ram_clicked"
QT_MOC_LITERAL(13, 172, 23), // "toolButton_Disk_clicked"
QT_MOC_LITERAL(14, 196, 22), // "toolButton_Pic_clicked"
QT_MOC_LITERAL(15, 219, 22), // "toolButton_Net_clicked"
QT_MOC_LITERAL(16, 242, 23), // "toolButton_Uart_clicked"
QT_MOC_LITERAL(17, 266, 24), // "toolButton_Mouse_clicked"
QT_MOC_LITERAL(18, 291, 26), // "toolButton_BLANKBD_clicked"
QT_MOC_LITERAL(19, 318, 22), // "toolButton_KBD_clicked"
QT_MOC_LITERAL(20, 341, 20), // "circleButton_clicked"
QT_MOC_LITERAL(21, 362, 18), // "checkFaultLog_Slot"
QT_MOC_LITERAL(22, 381, 19), // "deleteFaultLog_Slot"
QT_MOC_LITERAL(23, 401, 16), // "getUsbPidVidSlot"
QT_MOC_LITERAL(24, 418, 28), // "receive0x0AData_setText_Slot"
QT_MOC_LITERAL(25, 447, 14), // "unsigned char*"
QT_MOC_LITERAL(26, 462, 6), // "keyBuf"
QT_MOC_LITERAL(27, 469, 20), // "clearInfoUsbDateSlot"
QT_MOC_LITERAL(28, 490, 16), // "keyCodeClearSlot"
QT_MOC_LITERAL(29, 507, 27), // "sendUsbCommand_0x0AFlg_Slot"
QT_MOC_LITERAL(30, 535, 15), // "changeLabelTime"
QT_MOC_LITERAL(31, 551, 16), // "changeLabelfault"
QT_MOC_LITERAL(32, 568, 21), // "changeLableCircleDate"
QT_MOC_LITERAL(33, 590, 14), // "toggle_Picture"
QT_MOC_LITERAL(34, 605, 8), // "ram_test"
QT_MOC_LITERAL(35, 614, 9), // "disk_test"
QT_MOC_LITERAL(36, 624, 8), // "net_test"
QT_MOC_LITERAL(37, 633, 9), // "uart_test"
QT_MOC_LITERAL(38, 643, 20), // "query_SetKeyTextSlot"
QT_MOC_LITERAL(39, 664, 6), // "KeyBuf"
QT_MOC_LITERAL(40, 671, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(41, 703, 4), // "arg1"
QT_MOC_LITERAL(42, 708, 21), // "checkBox_stateChanged"
QT_MOC_LITERAL(43, 730, 5) // "state"

    },
    "Widget\0changeTestFlg\0\0changeTimeDate\0"
    "Tim\0changefaultDate\0date\0changeCircleDate\0"
    "onTimeout\0changeButtonStatus\0"
    "changePushButtonStatus\0changePrintButton\0"
    "toolButton_Ram_clicked\0toolButton_Disk_clicked\0"
    "toolButton_Pic_clicked\0toolButton_Net_clicked\0"
    "toolButton_Uart_clicked\0"
    "toolButton_Mouse_clicked\0"
    "toolButton_BLANKBD_clicked\0"
    "toolButton_KBD_clicked\0circleButton_clicked\0"
    "checkFaultLog_Slot\0deleteFaultLog_Slot\0"
    "getUsbPidVidSlot\0receive0x0AData_setText_Slot\0"
    "unsigned char*\0keyBuf\0clearInfoUsbDateSlot\0"
    "keyCodeClearSlot\0sendUsbCommand_0x0AFlg_Slot\0"
    "changeLabelTime\0changeLabelfault\0"
    "changeLableCircleDate\0toggle_Picture\0"
    "ram_test\0disk_test\0net_test\0uart_test\0"
    "query_SetKeyTextSlot\0KeyBuf\0"
    "on_comboBox_currentIndexChanged\0arg1\0"
    "checkBox_stateChanged\0state"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  189,    2, 0x06 /* Public */,
       3,    1,  192,    2, 0x06 /* Public */,
       5,    1,  195,    2, 0x06 /* Public */,
       7,    1,  198,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  201,    2, 0x0a /* Public */,
       9,    0,  202,    2, 0x08 /* Private */,
      10,    0,  203,    2, 0x08 /* Private */,
      11,    0,  204,    2, 0x08 /* Private */,
      12,    0,  205,    2, 0x08 /* Private */,
      13,    0,  206,    2, 0x08 /* Private */,
      14,    0,  207,    2, 0x08 /* Private */,
      15,    0,  208,    2, 0x08 /* Private */,
      16,    0,  209,    2, 0x08 /* Private */,
      17,    0,  210,    2, 0x08 /* Private */,
      18,    0,  211,    2, 0x08 /* Private */,
      19,    0,  212,    2, 0x08 /* Private */,
      20,    0,  213,    2, 0x08 /* Private */,
      21,    0,  214,    2, 0x08 /* Private */,
      22,    0,  215,    2, 0x08 /* Private */,
      23,    0,  216,    2, 0x08 /* Private */,
      24,    1,  217,    2, 0x08 /* Private */,
      27,    0,  220,    2, 0x08 /* Private */,
      28,    0,  221,    2, 0x08 /* Private */,
      29,    0,  222,    2, 0x08 /* Private */,
      30,    1,  223,    2, 0x08 /* Private */,
      31,    1,  226,    2, 0x08 /* Private */,
      32,    1,  229,    2, 0x08 /* Private */,
      33,    0,  232,    2, 0x08 /* Private */,
      34,    0,  233,    2, 0x08 /* Private */,
      35,    0,  234,    2, 0x08 /* Private */,
      36,    0,  235,    2, 0x08 /* Private */,
      37,    0,  236,    2, 0x08 /* Private */,
      38,    1,  237,    2, 0x08 /* Private */,
      40,    1,  240,    2, 0x08 /* Private */,
      42,    1,  243,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 25,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 25,   39,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::Int,   43,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Widget *_t = static_cast<Widget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->changeTestFlg((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->changeTimeDate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->changefaultDate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->changeCircleDate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->onTimeout(); break;
        case 5: _t->changeButtonStatus(); break;
        case 6: _t->changePushButtonStatus(); break;
        case 7: _t->changePrintButton(); break;
        case 8: _t->toolButton_Ram_clicked(); break;
        case 9: _t->toolButton_Disk_clicked(); break;
        case 10: _t->toolButton_Pic_clicked(); break;
        case 11: _t->toolButton_Net_clicked(); break;
        case 12: _t->toolButton_Uart_clicked(); break;
        case 13: _t->toolButton_Mouse_clicked(); break;
        case 14: _t->toolButton_BLANKBD_clicked(); break;
        case 15: _t->toolButton_KBD_clicked(); break;
        case 16: _t->circleButton_clicked(); break;
        case 17: _t->checkFaultLog_Slot(); break;
        case 18: _t->deleteFaultLog_Slot(); break;
        case 19: _t->getUsbPidVidSlot(); break;
        case 20: _t->receive0x0AData_setText_Slot((*reinterpret_cast< unsigned char*(*)>(_a[1]))); break;
        case 21: _t->clearInfoUsbDateSlot(); break;
        case 22: _t->keyCodeClearSlot(); break;
        case 23: _t->sendUsbCommand_0x0AFlg_Slot(); break;
        case 24: _t->changeLabelTime((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 25: _t->changeLabelfault((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 26: _t->changeLableCircleDate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 27: _t->toggle_Picture(); break;
        case 28: _t->ram_test(); break;
        case 29: _t->disk_test(); break;
        case 30: _t->net_test(); break;
        case 31: _t->uart_test(); break;
        case 32: _t->query_SetKeyTextSlot((*reinterpret_cast< unsigned char*(*)>(_a[1]))); break;
        case 33: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 34: _t->checkBox_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Widget::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::changeTestFlg)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::changeTimeDate)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::changefaultDate)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::changeCircleDate)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject Widget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Widget.data,
      qt_meta_data_Widget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(const_cast< Widget*>(this));
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}

// SIGNAL 0
void Widget::changeTestFlg(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Widget::changeTimeDate(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Widget::changefaultDate(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Widget::changeCircleDate(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
